# 03 — Database Schema Map

36 base tables across 20 migrations (the previous pack documented 35; **V11.1
added `public_rate_limits`**). RLS is enabled across the schema; mutations flow
through `SECURITY DEFINER` RPCs rather than direct table writes (see
[04](04-rpc-and-server-actions-map.md)). This map groups tables by domain and
flags the V11-relevant changes and integrity risks.

## Tables by domain

### Identity & branch
| Table | Purpose | Notes |
|---|---|---|
| `branches` | Shop branches | Multi-branch schema; one canonical public branch in practice |
| `branch_settings` | Per-branch config | Min order, same-day cutoff, **cancellation_window_minutes** (drives public cancel deadline) |
| `profiles` | Staff profiles + role | `role` ∈ staff/manager/owner; `is_active`; `branch_id` — the authority for every access check |

### Catalog
| Table | Purpose | Notes |
|---|---|---|
| `product_categories` | Category taxonomy | |
| `products` | Catalog items | `price_per_unit`, `cost_per_kg` (V6), `stock_status`, min/max order qty |

### Orders
| Table | Purpose | V11 change |
|---|---|---|
| `orders` | Customer orders | **V11.1: +`public_access_id` (uuid, unique, default gen_random_uuid), +`public_access_revoked_at`, +`public_access_version`.** The reference (`order_ref`) is now a display label only. |
| `order_items` | Order line items | snapshots name/price at order time |
| `order_status_events` | Status transition log | actor + note |
| `order_notes` | Internal staff notes | never customer-visible |
| `order_daily_sequences` / `order_annual_sequences` | Reference number generators | `next_order_ref` |

### Compliance
| Table | Purpose | Notes |
|---|---|---|
| `compliance_logs` | Food-safety log entries | |
| `compliance_readings` | Temperature readings | **V11.3b target:** opening ritual should write the official record here (temperature single-source dedup) — deferred |

### Suppliers & inventory
| Table | Purpose | Notes |
|---|---|---|
| `suppliers` | Supplier records | contact details never exposed publicly |
| `supplier_documents` | Certificates/docs | |
| `inventory_batches` | Stock batches | remaining quantity, source |
| `inventory_movements` | Stock movement ledger | |
| `inventory_waste_events` | Waste log (V3) | |
| `carcass_intakes` / `carcass_intake_cuts` | Carcass intake (V6.4) | links intake to cuts |
| `stock_count_lines` | Stock count capture (V10.2) | feeds the single correction door |

### Operations capture (V10)
| Table | Purpose |
|---|---|
| `ops_checklist_sessions` | Open/close ritual sessions (resume) |
| `ops_checklist_events` | Per-step capture events (incl. skips) |

### Messaging
| Table | Purpose | Notes |
|---|---|---|
| `sms_templates` | SMS message templates | |
| `sms_log` | SMS send attempts (V2 test mode) | records disabled/failed, never fakes "sent" |

### Audit (security-critical)
| Table | Purpose | V11.2 posture |
|---|---|---|
| `audit_logs` | System audit evidence | **Append-only** (trigger). **No INSERT/UPDATE/DELETE grant for anon/authenticated.** Written only via `SECURITY DEFINER` RPCs / `emit_audit_log`. |
| `audit_events` | UI-facing audit feed | Mirrored from `audit_logs` by trigger; append-only; forgeable insert policy **dropped** in V11.2 |
| `login_attempts` | Login throttling | feeds non-enumerating login |

### Release governance (V4)
| Table | Purpose |
|---|---|
| `release_deployments` | Deployment records |
| `release_verifications` / `release_verification_items` | Verification checklist |
| `release_certifications` | Certification (append-only via `prevent_release_certification_mutation`) |
| `expected_migrations` | Migration manifest for drift checks |

### Rate limiting (V11.1 — NEW)
| Table | Purpose | Notes |
|---|---|---|
| `public_rate_limits` | Fixed-window counters for public endpoints | RLS enabled, **no policies** — only `check_rate_limit` (SECURITY DEFINER) may touch it. `identity` is an opaque hash, never plaintext phone. Opportunistic prune of windows >1 day old. |

## RLS & write posture (summary)

- **RLS enabled** across the schema; row visibility is governed by branch-scoped
  policies (`is_branch_staff`, `is_branch_manager`, `current_profile_branch_id`).
- **Writes do not go direct.** Client roles call `SECURITY DEFINER` RPCs that
  validate actor + branch before mutating. V11.2 removed the last forgeable
  direct-insert path (audit tables).
- **`public_rate_limits` and audit tables are "no client write" by construction**
  — RLS + revoked grants + (for audit) append-only triggers.

## Integrity risks (carried + new)

| # | Risk | Severity | Status |
|---|---|---|---|
| 1 | **Demo-data fallback** in `src/lib/server/catalog.ts`: on missing service env *or* an errored/empty query, the storefront silently shows hardcoded demo products/branch instead of failing loudly. On a misconfigured production this hides a broken backend. | HIGH | **Open** (carried from previous pack) |
| 2 | **Yield numbers unverified** (`cut-sheets.ts`) drive real prices via `admin_commit_product_price_cost`. | HIGH | Open |
| 3 | **Temperature double-capture**: opening ritual and compliance readings are not yet a single source. | MEDIUM | **Deferred to V11.3b** |
| 4 | **Inventory truth**: depletion is not automatically driven by sales; remaining quantity relies on manual stock-count. | MEDIUM | Deferred (V11.5 inventory reconciliation) |
| 5 | Production schema is **behind** local: missing the three V11 migrations (confirmed by drift check). | BLOCKER (prod) | Open — see [18](18-production-seal-status.md) |

## Migration list (20, applied locally; 3 missing on remote)

```
202605290001 init                      202606011900 v4_operations_intelligence
202605300001 v2_phase_a_backbone       202606012030 v5_action_intelligence
202605300002 v2_phase_b_ops            202606021000 v6_product_cost
202605300003 v2_phase_c_admin_products 202606021100 v6_4_carcass_intake
202605300004 v2_phase_d_admin_ops      202606021500 v6_5_inventory_integrity
202605310001 v2_phase_e_sms_test_mode  202606031000 v6_6_inventory_reality
202605310002 v2_phase_e_customer_cancel 202606041700 v10_phase2_guided_capture
202605310003 v2_1_compliance_inventory  202606051200 v11_1_public_order_access   ← missing on remote
202606011430 v3_operational_system      202606051300 v11_1_seal_public_access     ← missing on remote
                                         202606051400 v11_2_audit_authenticity     ← missing on remote
```
