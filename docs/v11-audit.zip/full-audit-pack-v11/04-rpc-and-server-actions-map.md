# 04 — RPC & Server-Actions Map

Two write layers: **Postgres RPCs** (`SECURITY DEFINER`, the real authority) and
**Next.js server actions** (`"use server"`, the trusted callers). Every client
mutation goes action → RPC; no client writes a table directly.

## Postgres RPCs (by domain)

Security column: **SD** = SECURITY DEFINER (runs as table owner), **INV** =
SECURITY INVOKER (relies on RLS). Grant column = who may EXECUTE.

### Authorization helpers
| Function | Sec | Grant | Role |
|---|---|---|---|
| `current_profile_branch_id` | SD | authenticated | branch of caller |
| `current_profile_role` | SD | authenticated | role of caller |
| `is_branch_staff(branch)` | SD | authenticated | branch-scope gate used across RPCs |
| `is_branch_manager(branch)` | SD | authenticated | manager-scope gate |
| `set_updated_at`, `slugify` | — | — | utility triggers/helpers |

### Orders & checkout
| Function | Sec | Grant | Notes |
|---|---|---|---|
| `create_checkout_order(…)` | SD | anon, authenticated, service_role | **V11.1: returns `{orderRef, publicAccessId}`** (was text). Validates window/closure/capacity/min-order; idempotent; emits `order_created`. |
| `next_order_ref(branch, date)` | SD | — | reference generator (label only) |
| `transition_order_status(id,next,note)` | **INV** | authenticated | **V11.2: audit write re-routed through `emit_audit_log`** (the prior inline insert depended on the dropped grant). RLS-scoped order select; branch check; legal-transition check; `FOR UPDATE`. |
| `add_order_note(…)` | SD | authenticated | internal note |
| `get_public_order_status(public_access_id)` | SD STABLE | **anon**, authenticated, service_role | **V11.1: safe DTO only**, keyed by unguessable handle; no phone/email/raw id/notes. |
| `establish_public_order_access(ref, phone)` | SD | **service_role ONLY** | **V11.1 seal:** returns `{publicAccessId, version}` on ref+phone match; NULL otherwise (unknown ref ≡ wrong phone). Reachable only via the privileged server module. |
| `cancel_public_order(id, reason, expected_version)` | SD | **service_role ONLY** | **V11.1 seal:** row-locked, version-bound, status+deadline re-checked under lock; emits `order_status_changed`. |
| `cancel_order_by_ref(ref, phone)` | — | **DROPPED (V11.1)** | enumerable, lock-free cancel — removed |
| `get_public_order(ref)` | — | **DROPPED (V11.1)** | legacy reference→data reader — removed |

### Rate limiting (V11.1)
| Function | Sec | Grant | Notes |
|---|---|---|---|
| `normalize_phone(text)` | IMMUTABLE | — | single SQL authority for phone matching (mirrored in TS for tests) |
| `check_rate_limit(bucket, identity, max, window)` | SD | anon, authenticated, service_role | atomic fixed-window counter; identity is an opaque hash |

### Audit (V11.2)
| Function | Sec | Grant | Notes |
|---|---|---|---|
| `emit_audit_log(type,target_type,target_id,branch,metadata,system_reason)` | SD | **authenticated, service_role** (not anon) | Fail-closed trusted emitter: actor derived from `auth.uid()` (no actor param); system emission requires `system_reason` + records NULL actor; non-system caller may not claim system; branch scope validated; event_type allowlist; metadata ≤8192 bytes; **secret-like keys stripped**; `created_at` server-side. |
| `mirror_audit_log_to_event()` | — | trigger | mirrors `audit_logs` → `audit_events` |
| `prevent_audit_log_mutation()` / `prevent_audit_events_mutation()` | — | triggers | **append-only** enforcement (re-asserted in V11.2) |

### Products / pricing
`admin_create_product`, `admin_update_product`, `admin_update_product_price`,
`admin_set_product_availability`, `admin_set_product_cost`,
`admin_commit_product_price_cost` — all SD, manager-gated, emit pricing/product
audit events.

### Inventory
`admin_create_inventory_batch`, `admin_adjust_inventory_remaining`,
`admin_record_inventory_waste`, `admin_confirm_carcass_intake` — all SD,
manager-gated, emit `stock_*` / `waste_recorded` / `carcass_intake_confirmed`.

### Ops capture (V10)
`ops_start_or_resume_session`, `ops_record_step`, `ops_complete_session`,
`ops_record_stock_count_line`, `ops_apply_stock_count_line` — SD, manager-gated,
emit `ops_*` / `stock_count_*` events.

### Admin ops / windows / closures / settings
`admin_create/update/set_active_pickup_window`,
`admin_create/remove_shop_closure`, `admin_update_branch_settings` — SD,
manager-gated.

### Compliance / suppliers
`admin_upsert_supplier_cert` — SD, emits `certificate_*`.

### SMS
`record_sms_attempt` — SD; records disabled/failed honestly (never fakes "sent").

### Release governance (V4, owner)
`create_release_deployment`, `ensure_release_verification_items`,
`update_release_verification_item`, `certify_release`,
`prevent_release_certification_mutation`, `get_applied_migration_versions`,
`get_migration_health` — SD/owner-scoped; certifications append-only.

## Server actions (`src/app/actions/`, 12 modules)

| Module | Calls | Auth/boundary notes |
|---|---|---|
| `checkout.ts` | `submitCheckout` → `create_checkout_order`, then `grantOrderAccess(id, 1)` | Establishes the signed HttpOnly session. **Throws in prod if `ORDER_ACCESS_SECRET` unset** (fail-closed). |
| `establish-order-access.ts` | `establishPublicOrderAccess` (rate-limited, service-role module) → `grantOrderAccess` → redirect to status | Indistinguishable failure messages; no enumeration. |
| `cancel-order.ts` | `getOrderAccessVersion` (session) → `cancelPublicOrder(id, reason, version)` | **Requires an established session** (version≠null) before the service-role cancel RPC. |
| `counter.ts` | `transition_order_status`, notes | staff/manager only (middleware + RPC branch check) |
| `auth.ts` | Supabase auth + login-attempt throttling | non-enumerating errors; reads request headers |
| `admin-settings.ts` | `admin_update_branch_settings` | manager-gated |
| `admin-schedule.ts` | pickup windows + shop closures RPCs | manager-gated |
| `admin-products.ts` | product/price/availability RPCs | manager-gated |
| `compliance-inventory.ts` | inventory/waste/supplier-cert RPCs | manager-gated |
| `carcass-intake.ts` | `admin_confirm_carcass_intake` | manager-gated |
| `ops-capture.ts` | ops_* + stock-count RPCs | manager-gated |
| `releases.ts` | release governance RPCs | **owner-gated** |

## Audit emission — the single server path

`src/lib/server/audit.ts` (`emitAuditLog` / `emitSecurityEvent`) is the **only**
non-RPC place an audit row is created, and it is `server-only`. It uses the
service-role client purely as transport; `emit_audit_log` is the authority.
`audit-imports.test.ts` statically asserts: audit modules are `server-only`, no
client component imports them, and `emit_audit_log` is called **only** from
`audit.ts`. Business RPCs keep their own inline owner-context inserts (they
already validate the actor). See [15](15-audit-authenticity-map.md).

## Idempotency & safety highlights

- **Checkout** is idempotent on `idempotency_key` (returns the existing
  `{orderRef, publicAccessId}` on replay; handles `unique_violation`).
- **Public cancel** is race-safe: `FOR UPDATE` lock + conditional `UPDATE … WHERE
  status='incoming'` + `ROW_COUNT` check; a concurrent staff transition makes the
  customer cancel a no-op ("no longer cancellable"). Proven by the
  "race: exactly one winner" adversarial check.
- **Version binding**: a `public_access_version` bump invalidates outstanding
  cancel authority (compare-and-check in SQL).
