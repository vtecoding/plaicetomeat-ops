# 05 — Permissions & Roles Map

## Roles

Three staff roles (`src/lib/domain/route-access.ts`): **`staff`**, **`manager`**,
**`owner`**. Plus the implicit **public/anon** visitor. Roles come from
`profiles.role`; `profiles.is_active` must be true.

| Role | Can reach | Cannot reach |
|---|---|---|
| anon (public) | storefront, checkout, order lookup/status/cancel (with handle+session) | anything under `/counter`, `/admin` |
| staff | `/counter*` | `/admin*` |
| manager | `/counter*`, `/admin*` (except owner-only) | `/admin/releases`, `/admin/audit` |
| owner | everything | — |

## Four enforcement layers (defence in depth)

1. **Middleware** (`src/middleware.ts`, matcher `/counter/:path*`, `/admin/:path*`,
   `/compliance/:path*`). Validates the Supabase session via `getUser()` (not
   cookie-trust), loads `profiles.role`+`is_active`, calls `canAccessStaffPath`.
   Also enforces a **4-hour staff session timeout** (`STAFF_SESSION_TIMEOUT_MS`)
   via the `ptm_staff_last_seen` cookie. Owner-only paths checked **first** so the
   "owner returns true" shortcut can't widen manager access.
2. **Page/layout server checks** (`getCurrentProfile`, React-`cache`d). Always
   re-validates against Supabase Auth. Pages render nothing privileged without a
   valid profile.
3. **RPC authority** (`is_branch_staff` / `is_branch_manager` inside
   `SECURITY DEFINER` functions). Even if a UI check were bypassed, the database
   refuses cross-branch / under-privileged mutations. Order RPCs are RLS-scoped so
   another branch's order appears as "not found".
4. **Grants + RLS at the table** (V11.1/V11.2). Service-role-only on the two
   privileged public-order RPCs; **no client write grants** on audit tables;
   `public_rate_limits` reachable only via its SD function.

## Route-access logic (verbatim behaviour)

- `isOwnerOnlyPath` → `/admin/releases`, `/admin/audit` (owner only).
- `canAccessStaffPath`: owner-only paths require `owner`; then `owner` ⇒ true;
  `/admin*` requires `manager`; `/counter*` (+`/compliance*`) requires `staff` or
  `manager`.
- `isStaffSessionExpired`: stale `last_seen` (> 4h) ⇒ sign out + redirect home.

## Public-order authority (V11.1) — not a "role", a capability chain

The public order flow has no logged-in user, so access is a **capability**, not a
role:

- **Read** a status: possession of the unguessable `public_access_id` (the handle
  is the bearer token; the human reference is *not*).
- **Establish** access: prove identity (order ref + matching phone), rate-limited,
  via a server-only service-role module → grants a **signed HttpOnly session**.
- **Cancel**: requires the signed session (`getOrderAccessVersion ≠ null`) **and**
  the session's bound version to still match. See [14](14-security-boundary-map.md).

## Test coverage of the boundary

| Concern | Covered by |
|---|---|
| Unauthenticated redirect for every back-office route | `route-protection.spec.ts` |
| Staff cannot reach manager routes | `route-protection.spec.ts` |
| Managers cannot reach owner-only release/audit | `route-protection.spec.ts` |
| Public pages never leak back-office nav | `route-protection.spec.ts`, `storefront.spec.ts` |
| Non-enumerating login | `auth.spec.ts` |
| RPC branch/role gates | `verify-audit-authenticity.mjs` (branch-B emit denied), unit tests |
| Service-role not in client bundle | `public-route-imports.test.ts`, `audit-imports.test.ts` |

## Gaps / findings

1. **`/compliance/:path*` middleware matcher is dead** (no such top-level route).
   Harmless but should be pruned. LOW.
2. **No per-action CSRF token beyond same-origin + `form-action 'self'`.** Next.js
   server actions + the strict CSP `form-action 'self'` mitigate this; no extra
   token layer. Acceptable, noted.
3. **Owner is a superset of manager everywhere except the two owner-only tools.**
   There is no finer-grained capability model (e.g., a "pricing-only" manager).
   Not a defect for a single-shop owner-operator; noted for scale.
4. **Production enforcement is unverified.** All of the above is proven against
   the local stack only. See [18](18-production-seal-status.md).
