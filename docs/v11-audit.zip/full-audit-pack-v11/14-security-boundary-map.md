# 14 — Security Boundary Map (public order access)

Scope: the V11.1 public-order security boundary. Every required claim is proven
**by source + adversarial test**, with the honest caveat that this is **repository
/ local** proof, not production proof (see [18](18-production-seal-status.md)).

Evidence: `node scripts/verify-public-access.mjs` → **24/24 PASS**
([`_validation/verify-public-access.log`](_validation/verify-public-access.log)),
plus `public-route-imports.test.ts`, `order-access-token.test.ts`, and the
`safe-test-order` e2e (green when `ORDER_ACCESS_SECRET` is set).

## Architecture in one diagram

```
ANON browser
  │  read (handle is the bearer)            establish (ref+phone)      cancel (session)
  ▼                                          ▼                          ▼
get_public_order_status            establishOrderAccessAction     cancelOrderAction
  (SD, anon-granted, safe DTO)       │ rate-limit FAIL-CLOSED        │ require signed session
  public anon client                 ▼ service-role module           ▼ service-role module
                                   establish_public_order_access   cancel_public_order
                                   (SD, SERVICE_ROLE ONLY)         (SD, SERVICE_ROLE ONLY,
                                   → {id, version}                  version-bound, FOR UPDATE)
```

## Required claims — proven

### `order_ref never authorises public data` ✅
- The legacy reference reader `get_public_order(ref)` is **dropped** (V11.1 seal
  migration §3). The legacy `getOrderByRef` repo function is **removed**
  (`public-route-imports.test.ts` asserts it no longer exists).
- `/order/<ref>` and `/order/<ref>/cancel` are now pure **redirects** to
  `/order/lookup` and **read no order data** (source: both `page.tsx` files).
- Status read is keyed only by `public_access_id` (a random unique uuid), never by
  the reference. Adversarial: *"legacy get_public_order(ref) is removed/uncallable
  by anon"* → PASS.

### `cancel requires signed session authority` ✅
- `cancel_public_order` is **service_role only** (V11.1 seal: `REVOKE ALL … FROM
  anon, authenticated`). Anon cannot call it via PostgREST. Adversarial: *"anon
  cancel_public_order with VALID access id is DENIED"* → PASS.
- The only caller is `cancelOrderAction`, which **first** requires
  `getOrderAccessVersion(id) ≠ null` (a grant in the HMAC-signed HttpOnly cookie).
  e2e `safe-test-order`: a stranger browser at `/order/status/<id>/cancel` is asked
  to confirm identity and has **no** confirm-cancel button; the original
  (session-bearing) customer can cancel.
- Version binding: the cookie binds `{id, version}`; SQL compare-and-check rejects
  a stale version. Adversarial: *"cancel with wrong expected_version is rejected"*,
  *"order unchanged after version mismatch"* → PASS.

### `anon cannot call privileged public-order RPCs` ✅
- Both `establish_public_order_access` and `cancel_public_order`: `REVOKE ALL FROM
  PUBLIC, anon, authenticated; GRANT … TO service_role`.
- Adversarial: *"anon establish_public_order_access is DENIED"* → PASS.
- `get_public_order_status` and `check_rate_limit` **are** anon-granted by design
  (safe read + limiter); the read returns only the safe DTO.

### `service-role is not exposed to client bundles` ✅
- `order-access-privileged.ts` is `server-only` and is the **one** module allowed
  to use `createSupabaseServiceClient` for the public flow.
- `public-route-imports.test.ts` statically asserts the public surface (status
  page, cancel page, lookup, legacy redirects, both actions, `public-order-access`,
  session, rate-limit) imports **no** `createSupabaseServiceClient`, no
  `getOrderByRef`, no `ORDER_SELECT`, no `@/lib/server/orders`.
- The privileged module is contained: only the two safe RPCs, **no** `.from("orders")`,
  no internal select (asserted).

### `public access IDs are not logged` ✅
- The cancel RPC audit metadata "**deliberately excludes** public_access_id /
  session material" (comment + payload: only from/to/by/order_ref).
- `emit_audit_log` strips secret-like keys including `public_access` / `access_id`
  / `session` / `token` (V11.2 redaction regex). Adversarial (V11.2):
  *"secret-like keys are stripped from stored metadata"* → PASS.
- Error logging in the server modules logs `error.message` only, never the id.

### `old enumerable readers are gone` ✅
- `get_public_order(ref)` dropped; `cancel_order_by_ref(ref, phone)` dropped
  (V11.1 migration §7). Adversarial confirms the legacy path is uncallable.

## Supporting boundary controls

| Control | Implementation | Proof |
|---|---|---|
| **Rate limiting** | `public_rate_limits` (RLS, no policies) + `check_rate_limit` SD; establish/cancel **fail-closed**, status **fails-open** | adversarial *"rate limiter allows up to max then blocks"* → PASS; `rate-limit.ts` `failClosed` flags |
| **Non-enumeration** | unknown ref ≡ wrong phone (NULL); identical UI message | adversarial *"unknown-ref and wrong-phone establish results are identical (null)"* → PASS |
| **Safe DTO** | first-name only, no phone/email/notes/raw id; `findForbiddenFields` defence-in-depth | *"public DTO has no forbidden fields"*, *"DTO customerDisplayName is first-name only"* → PASS |
| **Isolation** | access id A returns only order A | *"access id A returns only order A"* → PASS |
| **Race safety** | `FOR UPDATE` + conditional update + ROW_COUNT | *"race: exactly one winner every time"* → PASS |
| **Revocation** | `public_access_revoked_at` re-checked under lock | *"revoked: status/establish/cancel all blocked"* → PASS |
| **Signed session** | HMAC-SHA256, constant-time verify, HttpOnly, `path=/order`, 14-day, ≤10 grants | `order-access-token.test.ts` round-trip; forged/tampered ⇒ `[]` |
| **Secret discipline** | `ORDER_ACCESS_SECRET` ≥32 bytes; **no silent prod fallback** | `order-access-session.ts` throws in prod; e2e confirms (README note 4) |

## Middleware & headers
- Middleware (`src/middleware.ts`) validates session via `getUser()`, enforces
  role + 4h timeout for `/counter*`, `/admin*`.
- Security headers (`next.config.ts`): `default-src 'self'`, `object-src 'none'`,
  `frame-ancestors 'none'`, `X-Frame-Options: DENY`, `nosniff`,
  `Referrer-Policy`, `Permissions-Policy`, HSTS in prod.
- **Known limitation:** CSP `script-src` includes `'unsafe-inline'` (Next App
  Router inline bootstrap; no nonce pipeline yet). Tracked follow-up; MEDIUM in
  [11](11-risk-and-duplication-map.md).

## Import-graph guardrails (static, in CI via vitest)
- `public-route-imports.test.ts` — public surface free of service-role/internal
  readers; privileged module contained.
- `audit-imports.test.ts` — audit emission server-only (see [15](15-audit-authenticity-map.md)).

## Honest caveats
- **All proof here is local.** The three V11 migrations are **not** on the
  production database (drift check FAIL). Until they are, production still runs the
  *old* enumerable behaviour. This is the single most important caveat.
- `ORDER_ACCESS_SECRET` **must** be set in production or checkout 500s
  (fail-closed). This is correct, but it is a deploy-time prerequisite.
