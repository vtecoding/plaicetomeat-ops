# 10 — User Workflow Map

Real human workflows for the three audiences, with the points where a
non-technical owner is likely to hesitate. V11.3 specifically targeted the owner's
"which door?" hesitation.

## Customer (anon)

### Place an order
1. `/shop` → `/product/[slug]` → **Add** → `/basket` → `/checkout`.
2. Fill name, UK mobile, pickup date, window → **Place pay-on-collection order**.
3. Land on `/order/status/<publicAccessId>` (the link to keep).
- **Hesitation:** "do I pay now?" — page states **pay on collection** clearly. Good.
- **Failure they'd see:** if prod lacks `ORDER_ACCESS_SECRET`, this step 500s.

### Check status later
- Bookmarked status link → live status by unguessable handle. No login.
- Lost the link? `/order/lookup` → order number + phone → re-establish access.
- **Hesitation:** "is my data safe by just a link?" — the handle is random/
  unguessable and exposes only first name + safe DTO. The *reference* reveals nothing.

### Cancel
- From status page (while "incoming" and within the window) → confirm.
- Without an established session, the cancel page **asks them to confirm identity
  first** (ref + phone) — they can't cancel a stranger's order.

## Counter staff

### Run service
1. `/counter` → live board (incoming → prepping → ready → collected).
2. Mark transitions; add internal notes; realtime updates (polling fallback if
   degraded, with no fake "live" badge).
- **Hesitation:** none significant; the board is the single counter surface now.
- Food-safety capture at `/counter/compliance` (nav "Food safety").

## Owner / manager

### "What do I do now?" → **Today** (only)
- `/admin/today`: Urgent / Important / Opportunities, plain language (Good /
  Needs attention / Unknown), money impact, decision cards.
- Optional `/admin/today/walk` guides through the day.
- **This is the consolidation win:** before V11.3 the owner faced Today *and*
  Briefing *and* the `/admin` dashboard all answering "today". Now it's one door.

### "How's the business?" → **Business Insights** (only)
- `/admin`: health score, findings (linked to playbooks), weekly report, confidence.
- Analysis only — no operational to-dos competing with Today.

### Open / close the shop
- `/admin/open` and `/admin/close`: guided checklists, resume across refresh,
  persisted receipt. Skipping a step is recorded honestly.

### Fix stock → **Stock count** (only)
- `/admin/stock-count`: count, apply a correction, resume. The normal door.
- Per-batch inventory correction still exists but is **owner-only** (an exception),
  so a manager isn't presented with three ways to change stock.

### Pricing
- `/admin/cutting-guide`: yields → cost → commit price.
- **Hesitation / risk:** the numbers *look* authoritative but are **unverified**.
  An owner trusting them could publish wrong prices. Flagged HIGH.

### Setup / onboarding
- `/admin/setup` + Today setup-mode: the single onboarding home (launch-readiness
  card was removed from `/admin` to stop the duplication).

### Owner-only
- `/admin/releases` (deploy + certify), `/admin/audit` (append-only evidence).
  Managers are blocked at the middleware.

## Where the owner still hesitates (honest)
1. **Compliance** is one page doing four jobs — "where do I log a cleaning record
   vs a temperature?" The split is deferred (V11.3b).
2. **Pricing confidence** — no "these yields are signed off" signal.
3. **Inventory trust** — stock only matches reality if someone runs the count;
   nothing reconciles against sales.
4. **"Is this live?"** — the owner cannot tell from the UI that production is
   running older code/schema. That's an operational reality, not a UI bug, but it
   is a real source of false confidence. See [18](18-production-seal-status.md).
