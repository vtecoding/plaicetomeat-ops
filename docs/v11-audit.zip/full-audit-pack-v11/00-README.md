# PlaiceToMeat — V11 Post-Consolidation Master Audit Pack

> Forensic, review-ready snapshot of the whole application **after** V11.1 (public
> order security), V11.2 (audit authenticity) and V11.3 (Owner-OS consolidation).
> Written to be read **without running the code**, but grounded in real source,
> real migrations, real RPCs, real Playwright runs and freshly-captured screenshots.
> Where something was not verified, it says so. Where the previous pack is now
> wrong, this pack says so.

## Provenance

| Field | Value |
|---|---|
| Repository | `plaicetomeat-ops` (Next.js 15.5.18 / React 19.1 / Supabase / Tailwind 4) |
| Branch | `v11-3-owner-os-consolidation` |
| Commit | `ac1603e` — _"V11.3 (core): Owner OS consolidation — one door per job"_ |
| Generated | 2026-06-06 |
| Baseline compared against | `docs/full-audit-pack/` (commit `db32b33`, V10 Phase 2, generated 2026-06-04) |
| Backend for runtime checks | local Supabase stack (`http://127.0.0.1:54321`, Docker up, `/auth/v1/health` → 200), all 20 migrations applied, seeded via `scripts/seed-dev.mjs` |
| Production build | `npm run build` → exit 0, 40 route entries, middleware 90.5 kB |
| Screenshot server | `npx next start -p 3100` (fresh production build), `ORDER_ACCESS_SECRET` supplied (see honesty note 4) |

## What this pack contains

| File | Covers |
|---|---|
| `00-README.md` | This file — provenance, method, honesty notes |
| `01-route-inventory.md` | Every route (40), access level, data deps, write paths, redirects |
| `02-admin-page-map.md` | Every admin page after consolidation: purpose, audience, verdict |
| `03-database-schema-map.md` | 36 base tables (+1 new), RLS posture, integrity risks |
| `04-rpc-and-server-actions-map.md` | All RPCs + 12 server-action modules, auth gates, audit emission |
| `05-permissions-and-roles-map.md` | Roles, the four enforcement layers, owner-only areas, gaps |
| `06-business-capability-map.md` | V1→V11 capability map by business area |
| `07-data-flow-map.md` | End-to-end flows incl. the rebuilt public-order flow |
| `08-admin-navigation-map.md` | Real nav after "one door per job"; before/after |
| `09-page-screenshot-index.md` | Index of the fresh `screenshots-v11/` set |
| `10-user-workflow-map.md` | Real human workflows; where the owner still hesitates |
| `11-risk-and-duplication-map.md` | Severity-ranked risk + duplication audit |
| `12-launch-readiness-map.md` | Category readiness with strict statuses |
| `13-v11-delta-map.md` | Old baseline vs current code — what changed |
| `14-security-boundary-map.md` | Public-order security boundary, proven claim-by-claim |
| `15-audit-authenticity-map.md` | Audit-forgery boundary, proven claim-by-claim |
| `16-owner-os-consolidation-map.md` | V11.3 "one door per job", proven with metrics |
| `17-playwright-coverage-map.md` | Every spec → route/role/workflow/boundary; gaps |
| `18-production-seal-status.md` | Repository security ≠ production security; seal state |
| `_validation/` | Raw captured outputs of every command run for this pack |
| `screenshots-v11/` | Fresh production-build screenshots + `_manifest.json` + contact sheets |

## Validation commands run for this pack (exact outcomes)

All commands were run on 2026-06-06 against commit `ac1603e`. Raw logs are in
[`_validation/`](_validation/).

| Command | Result | Notes |
|---|---|---|
| `npm run typecheck` | **PASS** (exit 0) | `tsc --noEmit` clean |
| `npm run test` (vitest) | **PASS** (exit 0) | 41 files, **288/288** tests |
| `npm run build` | **PASS** (exit 0) | 40 routes, production build clean |
| `npm run audit:bundle` | **PASS** (exit 0) | 430 tracked → 381 included / 49 denied; secret scan CLEAN |
| `node scripts/verify-public-access.mjs` | **PASS** (exit 0) | **24/24** sealed public-access adversarial checks |
| `node scripts/verify-audit-authenticity.mjs` | **PASS** (exit 0) | **41/41** audit-authenticity adversarial checks |
| `node scripts/check-migrations.mjs` (default) | **FAIL** (exit 1) | Drift vs the **linked/remote (production)** target: missing `202606051200`, `202606051300`, `202606051400`. See note 3. |
| `node --env-file=.env.local scripts/check-migrations.mjs` | **PASS** (exit 0) | Local stack has all 20 migrations applied |
| `npm run playwright` (no `ORDER_ACCESS_SECRET`) | **1 FAILED / 98 passed** (exit 1) | The one full-checkout e2e fails because the production server **correctly fails closed** without `ORDER_ACCESS_SECRET`. See note 4. |
| `npm run playwright` (with `ORDER_ACCESS_SECRET`) | see [17](17-playwright-coverage-map.md) / [`_validation/playwright-with-secret.log`](_validation/playwright-with-secret.log) | re-run to confirm green-when-configured |

## Honesty notes (read these before trusting any "PASS")

1. **Repository security is not production security.** Everything green here is
   green **locally**, against a local Supabase stack and a local production build.
   Production is a separate Supabase project + Vercel deploy updated manually. See
   [18-production-seal-status.md](18-production-seal-status.md). The headline state
   is **PRODUCTION SEAL PENDING**.

2. **The V11 work is a 3-deep unmerged PR stack.** PR #12 (V11.1) → `main`,
   PR #13 (V11.2) → #12's branch, PR #14 (V11.3) → #13's branch. All three are
   **OPEN**. The code audited here is the *tip of the stack* (`ac1603e`), which is
   ahead of `main`. `main` today has **none** of V11.1/V11.2/V11.3.

3. **The migration drift "FAIL" is a true production finding, not a tooling error.**
   `check-migrations.mjs` in its default (release) mode compares against the
   **linked remote** (production) project and reports the three V11 migrations
   missing there. The *local* DB has them (the authenticity/public-access
   adversarial suites exercise their behaviour and pass). Production is behind.

4. **The one Playwright failure is the fail-closed design working.** Against
   `next start` (NODE_ENV=production) **without** `ORDER_ACCESS_SECRET`, the
   checkout server action throws `ORDER_ACCESS_SECRET must be set with >= 32 bytes
   in production` (by design — V11.1 spec §6.7, no silent prod fallback). That
   makes the full-checkout e2e (`safe-test-order.spec.ts`) time out. With a
   ≥32-byte secret set, the flow completes. This is **positive evidence** the
   secret is mandatory in production — and a reminder that the production env
   **must** carry `ORDER_ACCESS_SECRET` or checkout will 500.

5. **Tests prove code paths, not business readiness.** 288 unit + a near-complete
   e2e suite prove the boundaries hold and the flows wire up. They do **not** prove
   a first-time butcher can run the shop, that yield/pricing numbers are correct,
   or that production is configured. Those are separate, still-open questions
   (see [11](11-risk-and-duplication-map.md), [12](12-launch-readiness-map.md)).

6. **Seed data, not real trading data.** Screenshots show seeded products, three
   seeded orders, light inventory and suppliers. Numbers are illustrative.

7. **Deferred work is real and named, not hidden.** V11.3b (compliance 4-domain
   split + temperature single-source dedup) and the later V11.x phases
   (checkout concurrency, checklist integrity, inventory reconciliation, pricing
   provenance, observability/recovery) are **not** done. See [13](13-v11-delta-map.md).

## One-line orientation for a new reviewer

Read [16](16-owner-os-consolidation-map.md) (what V11.3 did), then
[14](14-security-boundary-map.md) + [15](15-audit-authenticity-map.md) (the two
security boundaries, proven), then [18](18-production-seal-status.md) +
[12](12-launch-readiness-map.md) (why this is still not launch-ready despite a
green local gate). The engineering is genuinely strong and the security work is
real; the gap is entirely **production cutover, butcher sign-off on numbers, and
the deferred V11.x integrity phases.**
