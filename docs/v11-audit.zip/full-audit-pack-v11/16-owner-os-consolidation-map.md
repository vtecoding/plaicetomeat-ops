# 16 — Owner OS Consolidation Map (V11.3)

Goal: **one door per job.** This map proves whether V11.3 achieved its targets,
with before/after metrics. Source of record: `docs/v11/v11-3-consolidation-audit.md`
plus direct code inspection at `ac1603e`.

## Target invariants — verdicts

| Target | Verdict | Proof |
|---|---|---|
| **Today = operational home** | ✅ ACHIEVED | `/admin/today` is the only operational surface; `/admin/briefing` redirects here; `/admin` computes no "today" logic. e2e `owner-brain.spec.ts` (managers land on Today). |
| **Business Insights = analysis only** | ✅ ACHIEVED | `/admin` renders `business-insights.tsx` (health/findings/weekly/confidence) only; operational sections deleted. e2e `v8-briefing.spec.ts` ("analysis now lives on Business Insights"). |
| **Counter = live service only** | ✅ ACHIEVED | `/admin?mode=counter` branch removed; **0** `mode=counter`/`CounterServiceMode` refs in `src/`. `/counter` is sole. |
| **Orders = history/exceptions** | ✅ ACHIEVED (label) | `/admin/orders` reframed to history/search/exceptions; live prep at counter. Labelling only — no functional change. |
| **Stock Count = stock correction authority** | ✅ ACHIEVED | `/admin/stock-count` is the door; inventory per-batch "Correct stock" is **owner-only** exception; close ritual links here. |
| **Briefing retired** | ✅ ACHIEVED | `briefing/page.tsx` = 9-line `redirect("/admin/today")`. e2e `v8-briefing.spec.ts` ("/admin/briefing redirects to Today"). |
| **`/admin?mode=counter` removed** | ✅ ACHIEVED | query branch deleted; legacy URL falls through to Business Insights. |
| Navigation depth reduced | ✅ ACHIEVED | manager nav `Today + Briefing` → `Today + Business Insights`; staff `Counter + Compliance` → `Counter + Food safety`. |
| Existing functionality intact | ✅ (with caveat) | analysis preserved on `/admin`; owner can still adjust stock directly. Full regression green (288 unit, 99 e2e with secret). |

## Metrics (before → after)

| Metric | Before | After | Note |
|---|---|---|---|
| Operational "today" destinations | 3 | **1** | Today only |
| Counter experiences | 2 | **1** | `/counter` only |
| Stock-correction doors (normal workflow) | 3 | **1** | `/admin/stock-count` |
| `src/app/admin/page.tsx` lines | 934 | **481** | ~450 lines of operational logic removed |
| `src/app/admin/briefing/page.tsx` lines | 502 | **9** | redirect stub |
| admin route files | 23 | 23 | briefing kept as redirect (not deleted) |
| all route files | 40 | 40 | no page files deleted |
| components | 37 | 38 | +`business-insights.tsx` (shared, replaces duplicated render) |
| e2e specs | 33 | 33 | several rewritten to consolidated structure |

> **Why file counts are flat:** V11.3 used redirects + a shared component instead
> of hard deletes — safer on a branch stacked on two unmerged PRs. The real
> reduction is in **duplicated surfaces, duplicated queries, and ~900 lines of
> duplicated operational code**, not file count.

## What was deleted / merged / de-duplicated (component level)
- Deleted from `/admin/page.tsx`: `CounterServiceMode`, `buildOperationalIssues`,
  `buildDailyFocus`, `LaunchReadinessCard`, `LaunchReadinessRow`, `BadgePill`,
  `CompactMetricCard`, `severityTone`, and their sections.
- `getLaunchReadiness` no longer called from `/admin` (now only `/admin/setup` +
  Today setup-mode).
- `getShopIntelligence` called in **one** admin surface (`/admin`) instead of two.
- Operational "issues/daily focus/priority actions" computations removed from
  `/admin` (they overlapped Today's Owner Brain).
- Added: `src/components/admin/business-insights.tsx` (the lifted analysis sections).

## Stock authority change (detail)
`src/components/admin-inventory-client.tsx`: per-batch "Correct stock" form is now
**owner-only**; managers/staff see a link **"Correct stock in Stock count" →
`/admin/stock-count`**. The RPC (`admin_adjust_inventory_remaining`) and the
`compliance-inventory` action are **unchanged** (no inventory-architecture change);
waste logging unaffected. This is an authority/routing change, not a data change.

## Deferred to V11.3b (explicitly out of scope, NOT done)
- **Compliance 4-domain split** (Food Safety / Supplier Certificates / Cleaning
  Records / Operational Evidence). Only the nav **relabel** ("Food safety") shipped.
- **Temperature single-source dedup** (opening ritual writes the official
  `compliance_readings`; compliance reads the same record). Touches data capture —
  higher risk, focused follow-up.
- Any inventory-depletion / sales-decrement / forecasting work (spec Non-Goals).

## Verdict
V11.3 **achieved its core consolidation goal**: every operational job now has a
single authoritative surface, the duplicate dashboards and counter view are gone,
and navigation is simpler. Two consolidation items (compliance split, temperature
dedup) are deferred and clearly labelled. No functionality was lost.
