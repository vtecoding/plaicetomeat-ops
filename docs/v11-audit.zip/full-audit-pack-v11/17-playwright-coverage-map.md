# 17 — Playwright Coverage Map

Full suite: `npm run playwright` (`scripts/run-playwright.mjs full` → all of
`tests/e2e`, serial, 1 worker, against `next start -p 3100`).

## Headline result (honest)

| Run | Result | Log |
|---|---|---|
| Without `ORDER_ACCESS_SECRET` | **1 failed / 98 passed (exit 1)** | [`_validation/playwright.log`](_validation/playwright.log) |
| With `ORDER_ACCESS_SECRET` (≥32 bytes) | **99 passed / 0 failed (exit 0)** | [`_validation/playwright-with-secret.log`](_validation/playwright-with-secret.log) |

The single failure is **`safe-test-order.spec.ts`** and is **not a bug**: against
a production server (`next start`) the checkout calls `grantOrderAccess` →
`getSecret()`, which **throws by design** (`ORDER_ACCESS_SECRET must be set with
>= 32 bytes in production`, V11.1 spec §6.7) when the secret is absent. So the
checkout 500s, the redirect never happens, and `waitForURL` times out. With the
secret set, the full secure-boundary flow passes (`1.5s`). This is positive
evidence that the secret is **mandatory in production**.

## Spec → coverage matrix

| Spec | Route(s) | Role | Workflow | Security boundary | Screenshot? |
|---|---|---|---|---|---|
| `hosted-smoke` | `/`,`/shop`,`/basket`,`/checkout`,`/our-halal-promise`,`/counter`,`/admin*` | anon | renders + protection | back-office protected | yes |
| `storefront` | `/` | anon | homepage CTA, catalog/empty-state | no staff shortcut leak | yes |
| `halal-promise` | `/our-halal-promise` | anon | trust page | **no supplier contact leak** | yes |
| `checkout` | `/checkout` | anon | server validation | rejects bypassed invalid phone | yes |
| `phone-validation` | `/checkout` | anon | phone formats | input validation | — |
| `customer-trust` | order status/trust | anon | customer messaging | safe disclosure | yes |
| **`safe-test-order`** | `/checkout`→`/order/status/[id]`→cancel | anon | **full secure checkout + cancel** | **ref-not-a-credential; cancel needs session; stranger blocked** | yes (status/cancel) |
| `auth` | `/login` | anon | login | **non-enumerating error** | yes |
| `password-reset` | `/auth/update-password` | anon | reset | token flow | — |
| `route-protection` | `/counter*`,`/admin*`,owner-only | all | redirects | **staff≠manager≠owner; nav leak** | — |
| `counter-usability` | `/counter` | staff | service board UX | staff scope | yes |
| `counter-persistence` | `/counter` | staff | state persistence | — | — |
| `counter-realtime` | `/counter` | staff | realtime updates | — | — |
| `realtime-degraded` | `/counter` | staff | polling fallback (no fake live badge) | honest state | yes |
| `staff-notes` | `/counter` | staff | internal note persists, stays internal | **not customer-visible** | — |
| `sms-status` | order ready | staff | SMS attempt recorded | **never fakes "sent"** | — |
| `owner-brain` | `/admin/today`,`/today/[id]`,`/today/walk` | manager | TODAY decision cards, guided walk | **no scores/jargon to owner** | yes |
| `admin-dashboard` | `/admin` | manager | Business Insights panels | — | yes |
| `admin-action-dashboard` | `/admin` | manager | action intelligence | — | yes |
| `admin-mobile-dashboard` | `/admin` | manager | responsive | — | yes (mobile) |
| `v8-briefing` | `/admin/briefing`,`/admin` | manager/staff | **briefing→Today redirect; analysis on Business Insights** | **staff cannot reach analysis hub** | yes |
| `v4-ops-intelligence` | `/admin` | manager | insights + release/migration health + audit filters | owner tooling | yes |
| `setup-checklist` | `/admin/setup` | manager/owner | setup sections | **owner-only launch-safety panel** | yes |
| `owner-guide` | `/admin/guide` | manager | runbook | — | yes |
| `purchasing` | `/admin/purchasing` | manager | decision support + data-quality score | — | yes |
| `admin-products` | `/admin/products` | manager | catalog CRUD | manager-gated | yes |
| `admin-inventory` | `/admin/inventory` | manager | batches + waste board | manager-gated | yes |
| `waste-risk` | `/admin/inventory` | manager | honest risk summary | — | yes |
| `admin-suppliers` | `/admin/compliance` | manager | supplier certs | manager-gated | yes |
| `admin-pickup-windows` | `/admin/pickup-windows` | manager | window CRUD | manager-gated | yes |
| `admin-shop-closures` | `/admin/shop-closures` | manager | closure CRUD | manager-gated | yes |
| `cutting-guide` | `/admin/cutting-guide` | manager | yields → real cost (chiller shrinkage) | — | yes |
| `ops-capture` | `/admin/open|close|stock-count` | manager | rituals: record/skip/resume/receipt; stock correction | capture integrity | yes |

## Boundary coverage assessment

**Well covered:** route protection (all role pairings + owner-only), public-order
secure boundary (ref-not-credential, session-gated cancel, stranger blocked),
audit/disclosure honesty (no supplier leak, no fake SMS, internal notes stay
internal), consolidation (briefing redirect, analysis hub staff-blocked).

**Covered by the Node adversarial scripts, not Playwright** (and that's
appropriate — they need privileged DB access): the 24 public-access and 41
audit-authenticity invariants (`verify-public-access.mjs`,
`verify-audit-authenticity.mjs`). These exercise RLS/grant-level denials that a
browser cannot reach.

## Missing / thin coverage — stated bluntly

1. **No e2e for `/order/lookup` wrong-ref/wrong-phone non-enumeration via the
   browser.** The identical-failure invariant is proven at the RPC level
   (adversarial) but there is no browser test asserting the two error messages are
   identical. **Gap (LOW)** — covered in spirit by `safe-test-order` + adversarial.
2. **No e2e for cancellation *version invalidation* through the UI** (a bumped
   version rejecting a stale session). Proven in SQL/adversarial only. **Gap (LOW).**
3. **No e2e for the rate-limiter UI messages** ("too many attempts"). Limiter
   logic is unit/adversarial-tested; the friendly UI path is not browser-asserted.
   **Gap (LOW).**
4. **No e2e against owner-only `/admin/releases` / `/admin/audit` *content*** (only
   that managers are blocked). Owner-side rendering of release/audit tools is
   unverified by e2e. **Gap (MEDIUM)** — these are the most powerful tools.
5. **No production / hosted run in this pack.** `playwright:hosted` exists but was
   not run (no production cutover). **Gap (BLOCKER for launch, by design here).**

## Flaky-risk areas
- **`safe-test-order`** is environment-sensitive: it depends on `ORDER_ACCESS_SECRET`
  and on a future weekday pickup date / seeded "Lunchtime" window / capacity. Date
  arithmetic (skips Sunday only) could collide with a seeded shop closure on some
  calendar days. Treat as the most fragile spec.
- Realtime specs (`counter-realtime`) depend on Supabase realtime timing; run
  serially (workers:1) which mitigates contention but adds wall-clock time.
- All specs share one seeded DB and rely on `reset-state`/`resetStateBeforeEach`;
  a partial reset would cause order-count-sensitive failures. Re-seed before a run
  (this pack did: `seed-dev.mjs`).
