# 11 — Risk & Duplication Map

Severity-ranked. **BLOCKER** = must fix before public launch. **HIGH** = serious,
fix soon. **MEDIUM** = real, schedule it. **LOW** = cleanup.

## BLOCKER

| # | Risk | Evidence | Action |
|---|---|---|---|
| B1 | **Production not sealed.** The three V11 migrations are not on the production DB; PR stack #12/#13/#14 all open; `main` has none of V11.1–V11.3. Production still runs pre-V11 (enumerable refs, forgeable audit) behaviour. | `check-migrations.mjs` drift FAIL; `gh pr list` | Execute Production Gate A sequence — [18](18-production-seal-status.md). |
| B2 | **`ORDER_ACCESS_SECRET` production status unknown.** If unset/short in prod, **checkout 500s** (fail-closed). | e2e fail without secret; `order-access-session.ts` throws in prod | Set ≥32-byte secret in prod env **before** deploy; verify with hosted smoke. |

## HIGH

| # | Risk | Evidence | Action |
|---|---|---|---|
| H1 | **Demo-data fallback is silent.** `catalog.ts` falls back to hardcoded demo products/branch on missing service env *or* an errored/empty query → a misconfigured production silently shows fake products instead of failing loudly. | `src/lib/server/catalog.ts` | Make the fallback loud/observable in production (fail or banner), or gate it to dev only. |
| H2 | **Yield/pricing numbers unverified.** `cut-sheets.ts` yields drive `admin_commit_product_price_cost` → real customer prices. No butcher sign-off. | `src/lib/butchery/cut-sheets.ts`; `cutting-guide.spec.ts` tests math, not correctness | Butcher review + provenance (deferred to V11.8). |
| H3 | **PR-stack depth.** 3 open stacked PRs; merge-order-sensitive (audit-authenticity must not land before access boundary); growing rebase risk. | `gh pr list` | Land #12 + Gate A promptly; shorten the stack. |
| H4 | **No CI / GitHub Actions evident.** All gates run on one developer's machine; nothing enforces typecheck/test/adversarial/audit:bundle on push or PR. | no `.github/workflows` referenced; manual `run-playwright.mjs` | Add CI running typecheck + vitest + adversarial scripts + audit:bundle on PRs. |
| H5 | **Inventory truth unresolved.** Remaining stock is not auto-decremented by sales; relies on manual stock-count. Numbers can silently diverge from reality. | schema; V11.5 not started | Inventory reconciliation (V11.5). |

## MEDIUM

| # | Risk | Evidence | Action |
|---|---|---|---|
| M1 | **CSP `script-src 'unsafe-inline'`.** Next App Router inline bootstrap; no nonce pipeline. Weakens XSS defence-in-depth. | `next.config.ts:31`; documented follow-up | Add middleware nonce; remove `unsafe-inline`. |
| M2 | **Compliance temperature double-capture.** Opening ritual and `compliance_readings` are not a single source. | deferred V11.3b | Temperature single-source dedup (V11.3b). |
| M3 | **Compliance is one page doing four jobs.** Only nav relabel done. | `/admin/compliance`; V11.3b | 4-domain split (V11.3b). |
| M4 | **Rollback is documented, not tested.** Each migration has a manual rollback note; none exercised. | migration headers | Test a rollback in a staging project. |
| M5 | **No production observability.** No error-tracking/alerting pipeline evident; a prod checkout 500 (e.g. missing secret) would be invisible until a customer complains. | no instrumentation found | Add error tracking + uptime/synthetic checkout monitor (V11.9). |
| M6 | **Owner-only tools lack e2e content coverage.** Only "managers blocked" is tested; owner rendering of releases/audit is unverified by e2e. | [17](17-playwright-coverage-map.md) gap #4 | Add owner-side e2e. |

## LOW

| # | Risk | Evidence | Action |
|---|---|---|---|
| L1 | **Dead middleware matcher `/compliance/:path*`** — no such top-level route. | `src/middleware.ts:93` | Prune. |
| L2 | **Nav label vs route mismatch** ("Food safety" → `/counter/compliance`). | `site-header.tsx` | Resolve with V11.3b rename. |
| L3 | **Thin empty-states** make day-one analytics look sparse ("All clear"/"No waste recorded"). | screenshots | Add first-run guidance copy. |
| L4 | **No breadcrumbs**; back-nav contextual only. | admin pages | Optional polish. |

## Duplication audit (post-V11.3)

| Former duplication | Status |
|---|---|
| 3× "today" dashboards (`/admin/today`, `/admin/briefing`, `/admin`) | **RESOLVED** — one (Today); briefing redirects; `/admin` analysis-only |
| 2× counter views (`/counter`, `/admin?mode=counter`) | **RESOLVED** — `/admin?mode=counter` removed |
| 3× stock-correction doors | **RESOLVED** — single (`/admin/stock-count`); inventory adjust owner-only |
| Launch-readiness rendered on both `/admin` and `/admin/setup` | **RESOLVED** — only setup + Today setup-mode |
| `getShopIntelligence` called in two surfaces | **RESOLVED** — one (`/admin`) |
| ~900 lines duplicated operational code in `/admin` | **REMOVED** |
| Remaining: compliance one-page-four-jobs | **OPEN** (V11.3b) |

The aggressive duplication the previous pack flagged is largely **gone**. The
residual duplication is the compliance domain split, explicitly deferred.
