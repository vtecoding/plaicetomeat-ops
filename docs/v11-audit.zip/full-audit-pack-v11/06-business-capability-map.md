# 06 — Business Capability Map (V1 → V11)

What the system can actually do for the business, by area, with the version that
introduced it. This is "what exists", not "what is production-proven".

## Selling (storefront → order)
| Capability | Since | State |
|---|---|---|
| Public catalog from real data (with safe empty-state) | V1/V6 | Working; demo fallback risk (see [03](03-database-schema-map.md)) |
| Basket + checkout (pay-on-collection) | V1/V2 | Working; idempotent; capacity/closure/cutoff enforced in SQL |
| Pickup windows + capacity caps | V2 | Working |
| Shop closures block pickup dates | V2 | Working |
| **Secure order status by unguessable handle** | **V11.1** | Working (anon safe DTO) |
| **Identity-checked order lookup (ref + phone)** | **V11.1** | Working (rate-limited, non-enumerating) |
| **Session-gated online cancellation** | **V11.1** | Working (version-bound, race-safe) |
| SMS notifications | V2 | **Test-mode honest**; real sending gated by env; never fakes "sent" |

## Running service (counter)
| Capability | Since | State |
|---|---|---|
| Live counter board (incoming→prepping→ready→collected) | V2 | Working; realtime + polling fallback |
| Staff notes (internal) | V2 | Working |
| Food-safety / compliance capture | V2.1 | Working; **4-domain split deferred (V11.3b)** |
| Single counter experience | **V11.3** | `/admin?mode=counter` removed; `/counter` is sole |

## Owner operating system
| Capability | Since | State |
|---|---|---|
| TODAY (Owner Brain: urgent/important/opportunities, decision cards, money impact, plain language) | V9 | Working; **sole operational home (V11.3)** |
| Guided shop day / open & close rituals (resume + receipt) | V10 | Working |
| Stock count as the single correction door | V10/**V11.3** | Working |
| Business Insights (health score, findings, weekly report, confidence) | V8 | Working; **sole analysis home (V11.3)** |
| Operational playbooks linked from findings | V8 | Working |
| Setup checklist / launch readiness (single onboarding home) | V7/**V11.3** | Working |

## Pricing & inventory
| Capability | Since | State |
|---|---|---|
| Product cost + price commit | V6 | Working |
| Cutting & pricing guide (yields) | V6.2–V6.3 | Working; **numbers unverified by a butcher** |
| Yield guardrails + visual cut maps | V6.2 | Working |
| Carcass intake → cuts | V6.4 | Working |
| Inventory batches + waste board | V2.1/V3/V6.5/V6.6 | Working; **no auto-depletion from sales** (deferred V11.5) |
| Purchasing decision support + data-quality score | V4/V5 | Working (honest "unknown" states) |

## Governance & trust
| Capability | Since | State |
|---|---|---|
| Append-only audit log + UI audit feed | V2/V3 | Working |
| **Non-forgeable audit evidence** | **V11.2** | Working (server-only emission; forgeable policies dropped) |
| Release governance (deploy + certify, migration health) | V4 | Working (owner-only) |
| Security headers (CSP/HSTS/XFO/…) | V11.1 | Working; **CSP `script-src` still allows `unsafe-inline`** (Next inline bootstrap; nonce pipeline is a follow-up) |
| Reproducible sanitized audit bundle (secret-scanned) | V11.0 | Working (`audit:bundle` CLEAN) |

## What it still cannot do (honest gaps)
- Automatically reconcile inventory against sales (manual stock-count only).
- Prove yield/price correctness (no butcher sign-off).
- Run in production with these V11 boundaries (migrations not deployed).
- Recover automatically (no documented automated rollback; manual `vercel`/`supabase db push`).
- Observe itself in production (no error-tracking/alerting pipeline evident).
