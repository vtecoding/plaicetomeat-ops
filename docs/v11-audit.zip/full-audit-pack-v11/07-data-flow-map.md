# 07 — Data-Flow Map

End-to-end flows: UI → server action → RPC → tables → audit, with failure modes.
The headline change vs the previous pack is the **rebuilt public-order flow**.

## 1. Checkout (public)
```
/checkout (form)
  → createOrderAction (checkout.ts)
    → submitCheckout → RPC create_checkout_order(branch, customer, items, idem)
        validates: window active, day-of-week, closure, same-day cutoff, capacity,
                   item availability, min order value
        writes: orders (+public_access_id v1), order_items, order_status_events('incoming')
        emits:  audit_logs('order_created')
        returns {orderRef, publicAccessId}
    → grantOrderAccess(publicAccessId, 1)  [signed HttpOnly cookie, path=/order]
  → redirect to /order/status/<publicAccessId>
```
Failure modes: empty/invalid basket → friendly message; capacity/closure/cutoff →
specific SQL message; **missing `ORDER_ACCESS_SECRET` in prod → 500 (fail-closed)**;
idempotent replay → returns existing order.

## 2. Order status read (public, anon)
```
/order/status/<publicAccessId>
  → getPublicOrderStatus(id)  [anon public client, NOT service role]
    → rate limit (fail-OPEN: customers still see status on limiter outage)
    → RPC get_public_order_status(id) → safe DTO (orderRef label, first name only,
       status, pickup, items, subtotal, canCancel, deadline)
    → findForbiddenFields() defence-in-depth: block any internal field leak
```
Failure modes: unknown/revoked id → not found (`notFound()`); limiter tripped →
"too many requests"; missing public env → "temporarily unavailable".

## 3. Establish access (public, ref + phone)
```
/order/lookup (form)
  → establishOrderAccessAction
    → establishPublicOrderAccess(ref, phone)  [service-role module]
        rate limit (fail-CLOSED: outage must not enable brute force)
        → RPC establish_public_order_access(ref, normalize_phone(phone))
            → {publicAccessId, version} on match, else NULL (ref≡phone failure)
    → grantOrderAccess(id, version) → redirect to status
```
Failure modes: wrong ref/phone → identical "couldn't find" message (no
enumeration); limiter → "try later"; outage → "call the shop".

## 4. Cancel (public, session-gated)
```
/order/status/<id>/cancel (form)
  → cancelOrderAction
    → getOrderAccessVersion(id)  [from signed session]; NULL ⇒ "confirm identity first"
    → cancelPublicOrder(id, reason, version)  [service-role module, rate-limited fail-closed]
        → RPC cancel_public_order(id, reason, expected_version)
            FOR UPDATE lock; re-check revoked/version/status='incoming'/deadline
            conditional UPDATE…WHERE status='incoming'; ROW_COUNT guard
            writes order_status_events('cancelled'); emits audit_logs
```
Failure modes: no session → asked to confirm identity; version bumped/expired/
already prepping → "no longer cancellable"; concurrent staff transition → customer
cancel becomes a no-op (exactly one winner).

## 5. Counter status transition (staff)
```
/counter → counter action → RPC transition_order_status(id, next, note)
  RLS-scoped order select; is_branch_staff check; legal-transition check; FOR UPDATE
  writes orders.status + order_status_events
  emits audit via emit_audit_log (V11.2 re-route)  ← actor = auth.uid()
```

## 6. Pricing commit (manager)
```
/admin/cutting-guide → admin-products action
  → RPC admin_commit_product_price_cost (cost from yields → price)
  emits audit_logs('pricing_committed')
```
Risk: yields unverified → committed prices may be wrong (HIGH).

## 7. Inventory correction (single door, V11.3)
```
/admin/stock-count → ops-capture action
  → ops_record_stock_count_line / ops_apply_stock_count_line
  → admin_adjust_inventory_remaining (owner-only direct path exists as exception)
  emits stock_count_* / stock_corrected
```

## 8. Open/close ritual capture (V10)
```
/admin/open|close → ops-capture action
  → ops_start_or_resume_session (resume across refresh)
  → ops_record_step (incl. skip as a real recorded state)
  → ops_complete_session → persisted receipt
```

## 9. Audit emission (system/server)
```
business RPC (owner context)  ──┐
emitAuditLog (server-only) ─────┼──► emit_audit_log (SD, fail-closed)
                                │      actor=auth.uid()|NULL(system+reason)
                                │      allowlist + metadata redaction
                                └──► audit_logs ──trigger──► audit_events (append-only)
                                                  → /admin/audit feed
```

## 10. SMS (honest test mode)
```
status change → record_sms_attempt → sms_log (disabled/failed recorded truthfully)
```

## Cross-cutting failure semantics
- **Fail-closed** where forgery/brute-force matters: establish, cancel, audit
  emit, checkout session secret.
- **Fail-open** only where it can't grant authority: status *read* limiter
  (the unguessable id is still the credential).
- **Demo-data fallback** in catalog is the one place a failure is *silent* — and
  is the standout risk (HIGH).
