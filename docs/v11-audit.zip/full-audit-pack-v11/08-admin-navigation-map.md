# 08 — Admin Navigation Map

The real navigation as rendered by `src/components/site-header.tsx`, plus the
"More" surfaces reachable from Today. V11.3 deliberately **shrank** the nav.

## Header nav (by role)

```
PUBLIC:   Shop · Halal Promise · Basket
+STAFF:   Counter · Food safety            (Food safety = /counter/compliance)
+MANAGER: Today · Business Insights
```

`isStaff = staff|manager|owner`; `isManager = manager|owner`. Owner sees the same
header as manager; the owner-only tools (`/admin/releases`, `/admin/audit`) are
reached from within the admin surfaces, not the top nav.

## Before → after (V11.3)

| Audience | Before | After |
|---|---|---|
| Manager top nav | `Today` + **`Briefing`** | `Today` + **`Business Insights`** |
| Staff top nav | `Counter` + **`Compliance`** | `Counter` + **`Food safety`** (relabel; route unchanged) |
| Today "More" grid | included a **Briefing** card; `/admin` card unlabelled | Briefing card **dropped**; `/admin` card relabelled **Business Insights** |

## Why this matters

The previous pack's #1 navigation finding was **three doors to "how's the shop
today"** (`/admin/today`, `/admin/briefing`, `/admin`) and **two doors to live
service** (`/counter`, `/admin?mode=counter`). After V11.3:

- "What do I do now?" → **Today** (only).
- "How's the business?" → **Business Insights** (only).
- "Run the counter" → **Counter** (only).
- "Fix stock" → **Stock count** (only; inventory adjust is an owner exception).

Briefing is a redirect; `mode=counter` is gone (0 references in `src/`). See
[16-owner-os-consolidation-map.md](16-owner-os-consolidation-map.md).

## Residual navigation findings
- The header is intentionally minimal; deeper admin pages are reached via Today's
  "More" grid and contextual links rather than a mega-menu. Good for a
  non-technical owner; a reviewer should use [01](01-route-inventory.md) for the
  full surface, since not every admin route is one click from the header.
- **No breadcrumb component**; back-navigation relies on browser + contextual
  "back to dashboard" links (present on e.g. purchasing). Minor.
- Label/route mismatch: nav says **"Food safety"** but the route is
  `/counter/compliance` and the page is still the combined compliance page — the
  structural rename is deferred to V11.3b. Cosmetic-but-worth-knowing.
