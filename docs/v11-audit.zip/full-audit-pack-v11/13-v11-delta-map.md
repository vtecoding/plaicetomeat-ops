# 13 — V11 Delta Map (old baseline vs current code)

Compares the previous master audit pack baseline (`docs/full-audit-pack/`, commit
`db32b33`, V10 Phase 2, 2026-06-04) against the current code (`ac1603e`,
V11.3 build-ahead). The old pack is treated as **evidence to confirm/supersede**,
not truth.

## Routes

### Added
| Route | Why |
|---|---|
| `/order/lookup` | V11.1 identity-checked access (ref + phone) |
| `/order/status/[publicAccessId]` | V11.1 secure status read by unguessable handle |
| `/order/status/[publicAccessId]/cancel` | V11.1 session-gated cancellation |

### Redirected (retired but kept as stubs)
| Route | Now | Since |
|---|---|---|
| `/order/[orderRef]` | → `/order/lookup` (no data read) | V11.1 |
| `/order/[orderRef]/cancel` | → `/order/lookup` | V11.1 |
| `/admin/briefing` | → `/admin/today` (9-line stub) | V11.3 |

### Removed behaviour (not files)
| Behaviour | Status |
|---|---|
| `/admin?mode=counter` (duplicate counter view) | **removed** (0 refs in `src/`) |
| Reference-keyed order data page | **removed** (redirect only) |
| Reference-only cancellation | **removed** (SQL function dropped) |

### Renamed (label)
| Old | New | Route |
|---|---|---|
| "Briefing" (nav) | "Business Insights" | `/admin` |
| "Compliance" (nav) | "Food safety" | `/counter/compliance` (route unchanged) |
| `/admin/orders` "orders" | "order history / exceptions" | unchanged route |

## Dashboard duplication removed
- Three "today" surfaces → **one** (`/admin/today`). `/admin` is analysis-only.
- `/admin/page.tsx`: 934 → **481** lines; operational logic + counter mode +
  launch-readiness card deleted.
- New shared `business-insights.tsx` replaces the duplicated analysis render.
- See [16](16-owner-os-consolidation-map.md) for full metrics.

## Database
| Change | Migration | Notes |
|---|---|---|
| `orders` +`public_access_id`, +`public_access_revoked_at`, +`public_access_version` | `202606051200` | unguessable handle + versioning |
| New table `public_rate_limits` | `202606051200` | fixed-window limiter |
| New funcs `normalize_phone`, `check_rate_limit`, `get_public_order_status`, `establish_public_order_access`, `cancel_public_order` | `202606051200/300` | secure public flow |
| `create_checkout_order` now returns jsonb `{orderRef, publicAccessId}` | `202606051200` | was text |
| Dropped `get_public_order(ref)`, `cancel_order_by_ref(ref,phone)` | `202606051200/300` | enumerable readers gone |
| `establish`/`cancel` made **service_role only** | `202606051300` | seal |
| Audit: forgeable insert policies dropped; client writes revoked; `emit_audit_log` added; `transition_order_status` re-routed | `202606051400` | audit authenticity |

## Security posture
| Aspect | Before (V10) | After (V11) |
|---|---|---|
| Order reference | authorised data + cancel (enumerable) | **display label only** |
| Public cancel | by ref + phone, lock-free | session-gated, version-bound, row-locked, service-role only |
| Audit evidence | forgeable by any authenticated user | **non-forgeable**, append-only, server-only emission |
| Security headers | minimal | CSP/HSTS/XFO/nosniff/Referrer/Permissions (CSP `unsafe-inline` caveat) |
| Service-role exposure | n/a | contained, import-graph-guarded |
| Reproducible review bundle | none | `audit:bundle` (secret-scanned) |

## Public order security changes
Fully covered in [14](14-security-boundary-map.md). Headline: order_ref no longer
authorises anything; read = unguessable handle; cancel = signed session + version;
privileged RPCs are service-role only; old enumerable readers dropped.

## Audit authenticity changes
Fully covered in [15](15-audit-authenticity-map.md). Headline: forgeable insert
policies dropped, client writes revoked, single fail-closed emitter, append-only
re-asserted, self-enforcing migration assertion.

## Counter-mode removal & stock correction authority
- Counter mode: removed (above).
- Stock correction: now single-door (`/admin/stock-count`); inventory per-batch
  correction owner-only. See [16](16-owner-os-consolidation-map.md).

## Remaining deferred items (NOT done in V11.0–V11.3)
| Item | Target phase |
|---|---|
| Compliance 4-domain split | V11.3b |
| Temperature single-source dedup | V11.3b |
| Checkout & capacity concurrency correctness | V11.x |
| Checklist & operational-evidence integrity | V11.4 |
| Inventory reconciliation integrity (auto-depletion) | V11.5 |
| Pricing & cost truth (yield provenance / butcher sign-off) | V11.8 |
| Production failure semantics (observability, recovery) | V11.9 |
| CSP nonce (remove `unsafe-inline`) | V11.1 follow-up |
| **Production cutover of V11.1/V11.2/V11.3 migrations** | Production Gate A (pending) |

## What in the old pack is now superseded
- Old pack's "three today dashboards" / "two counter doors" duplication findings →
  **resolved** (V11.3).
- Old pack's "order reference enumerable" implicit assumption → **superseded**
  (V11.1).
- Old pack table count "35 tables + 1 view" → now **36 base tables** (+`public_rate_limits`).
- Old pack still-valid carry-overs: demo-data fallback (HIGH), yield numbers
  unverified (HIGH), manual single-person release process, local ≠ production.
