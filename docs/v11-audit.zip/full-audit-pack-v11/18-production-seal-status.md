# 18 — Production Seal Status

> **Repository security is not production security.**

Everything green in this pack is green **locally**, against a local Supabase stack
and a local production build. None of the V11 security work is live until it is
deployed and verified in production. The headline status is:

## PRODUCTION SEAL PENDING

## Evidence-based status table

| Item | Status | Basis |
|---|---|---|
| PR #12 (V11.1 public order access) | **OPEN**, base `main` | `gh pr list` |
| PR #13 (V11.2 audit authenticity) | **OPEN**, base `v11-public-order-access` (stacked on #12) | `gh pr list` |
| PR #14 (V11.3 owner-OS consolidation) | **OPEN**, base `v11-2-audit-authenticity` (stacked on #13) | `gh pr list` |
| PR #11 (V11.0 baseline/governance) | **MERGED** to `main` | `gh pr list` |
| Production migration `202606051200` (V11.1 access) | **NOT APPLIED** on remote | `check-migrations.mjs` drift FAIL |
| Production migration `202606051300` (V11.1 seal) | **NOT APPLIED** on remote | drift FAIL |
| Production migration `202606051400` (V11.2 audit) | **NOT APPLIED** on remote | drift FAIL |
| `ORDER_ACCESS_SECRET` in production | **UNKNOWN / UNVERIFIED** (required ≥32 bytes or checkout 500s) | not present in local `.env.local`; prod env not inspectable from here |
| Deployed commit (Vercel prod) | **UNKNOWN** | no production access in this session |
| Production smoke (`playwright:hosted`) | **NOT RUN** | requires deployed build |
| Migration parity (local vs prod) | **FAIL** (prod is behind by 3 migrations) | drift check |
| Rollback readiness | **PARTIAL / DOCUMENTED ONLY** | each V11 migration documents a manual rollback; no automated/tested rollback |

## What "behind by 3 migrations" actually means for users today

Until the three V11 migrations are applied to the production database, the
**production app still runs the pre-V11.1 behaviour** even if the V11 *code* were
deployed — and worse, the code expects the new schema. Concretely, on production
right now:

- The enumerable order-reference readers may still exist
  (`get_public_order`, `cancel_order_by_ref` not yet dropped there).
- The forgeable audit insert policies may still be present.
- `orders.public_access_id` and `public_rate_limits` may not exist, so the new
  code paths would error against the old schema.

This is why **code merge order matters** and is documented in the V11 phase
evidence: merge #12 → execute Production Gate A (apply migrations + verify) →
archive prod evidence → rebase/merge #13 → verify audit authenticity in prod →
then #14. None of these production steps have been executed.

## The PR-stack risk

Three open, stacked PRs (#12 ← #13 ← #14) means:
- `main` has **none** of V11.1/V11.2/V11.3.
- Each merge must happen **in order**, with a production migration + verification
  between #12 and #13 (Gate A). A merge out of order, or a squash that reorders
  commits, risks applying audit-authenticity before the access boundary, or
  shipping code ahead of schema.
- The longer the stack stays open, the more `main` drifts and the harder the
  eventual rebase. **HIGH** operational risk — see [11](11-risk-and-duplication-map.md).

## Local proof that IS solid (do not discount it)

- 288/288 unit, 99/99 e2e (with secret), typecheck clean, build clean.
- 24/24 public-access adversarial, 41/41 audit-authenticity adversarial.
- `audit:bundle` secret scan CLEAN.
- Local migration parity PASS.

The security **design** is real and verified at the repository level. The gap is
entirely **execution against production**.

## To reach "SEALED" (production), the operator must:
1. Set `ORDER_ACCESS_SECRET` (≥32 bytes) in the production environment.
2. Merge #12; apply `202606051200` + `202606051300` to prod (`supabase db push`).
3. Execute **Production Gate A** verification against prod; archive evidence.
4. Merge #13; apply `202606051400`; verify audit authenticity against prod.
5. Merge #14; deploy; run `playwright:hosted` smoke against the deployed URL.
6. Re-run `check-migrations.mjs` against the linked remote → expect **PASS**.
7. Confirm rollback procedure is tested, not just documented.

Until **all** of the above are done and evidenced, this remains
**PRODUCTION SEAL PENDING**. Do not describe the system as "launch-ready".
