# 02 — Admin Page Map (post-consolidation)

Every manager/owner admin page after V11.3 "one door per job", with purpose,
audience, overlap status, and a blunt verdict. The big V11.3 change is that the
**operational** vs **analysis** split is now real: `/admin/today` owns "what do I
do now", `/admin` (Business Insights) owns "how is the business doing".

| Page | Audience | Purpose | Overlap after V11.3 | Verdict |
|---|---|---|---|---|
| `/admin/today` | Owner/manager | The operational home: Urgent / Important / Opportunities + decision cards. Owner-Brain language firewall (Good / Needs attention / Unknown, money impact). | **Sole** operational home. Briefing redirects here; `/admin` no longer computes "today" logic. | **KEEP — canonical.** This is the front door. |
| `/admin/today/[id]` | Owner/manager | Standardised decision card for one issue. | none | KEEP |
| `/admin/today/walk` | Owner/manager | Optional guided walk through the day (V10). | none | KEEP (optional path) |
| `/admin` | Owner/manager | **Business Insights** — health score, findings, weekly report, confidence. Analysis only. | De-duplicated: was a mixed operational+analysis dashboard (934 lines → 481). Counter mode, daily focus, launch-readiness card all removed. | **KEEP — now single analysis home.** |
| `/admin/briefing` | — | Retired. 9-line `redirect("/admin/today")` stub. | n/a | **RETIRED** (kept as redirect for bookmarks). |
| `/admin/open` | Owner/manager | Opening ritual checklist (guided capture, resume, receipt). | none | KEEP |
| `/admin/close` | Owner/manager | Closing ritual checklist; links into stock capture. | none | KEEP |
| `/admin/stock-count` | Owner/manager | **The** stock-correction door: count, apply correction, resume. | De-duplicated: inventory per-batch "Correct stock" is now owner-only exception; close ritual links here. | **KEEP — single correction authority.** |
| `/admin/orders` | Owner/manager | Order **history**, search, exceptions. Live prep happens at the Counter. | Reframed (label only) so it stops competing with `/counter`. | KEEP |
| `/admin/products` | Owner/manager | Catalog CRUD, price, availability. | none | KEEP |
| `/admin/inventory` | Owner/manager | Inventory batches + waste board. Per-batch correction owner-only; others routed to stock-count. | Correction authority moved out (V11.3). | KEEP |
| `/admin/purchasing` | Owner/manager | Purchasing decision support + honest data-quality score. | none | KEEP |
| `/admin/cutting-guide` | Owner/manager | Cutting & pricing guide; yields drive cost/price. | none | **KEEP, but numbers unverified** — see note below. |
| `/admin/compliance` | Owner/manager | Compliance dashboard + supplier certificates. | Nav relabelled "Food safety"; the structural 4-domain split is **deferred to V11.3b**. | KEEP; **split still pending.** |
| `/admin/pickup-windows` | Owner/manager | Pickup window CRUD. | none | KEEP |
| `/admin/shop-closures` | Owner/manager | Shop closure CRUD. | none | KEEP |
| `/admin/settings` | Owner/manager | Branch settings (cutoffs, min order, cancellation window). | none | KEEP |
| `/admin/setup` | Owner/manager | Guided setup checklist; **single onboarding home** (launch-readiness card removed from `/admin`). | De-duplicated launch-readiness (was also on `/admin`). | KEEP |
| `/admin/guide` | Owner/manager | Owner guide / runbook. | none | KEEP |
| `/admin/playbooks` + `/[slug]` | Owner/manager | Operational playbooks; findings link here. | none | KEEP |
| `/admin/releases` | **Owner only** | Release governance, deployment + certification. | none | KEEP (owner-only) |
| `/admin/audit` | **Owner only** | Append-only audit investigation with filters. | none | KEEP (owner-only) |

## Consolidation verdict

The duplication that the previous pack flagged hardest — **three "today"
dashboards** (`/admin/today`, `/admin/briefing`, `/admin`) and **two counter
experiences** (`/counter`, `/admin?mode=counter`) — is resolved. See
[16-owner-os-consolidation-map.md](16-owner-os-consolidation-map.md) for the
proof and metrics. Component-level: `/admin/page.tsx` dropped from 934 → 481
lines; `business-insights.tsx` was added as the single shared analysis component.

## Open page-level findings

1. **`/admin/cutting-guide` numbers are unverified.** Yield percentages in
   `src/lib/butchery/cut-sheets.ts` drive cost/price. No butcher has signed them
   off. An authoritative-looking wrong price is worse than no price. (Carried
   over from the previous pack — still true.) See [11](11-risk-and-duplication-map.md).
2. **`/admin/compliance` is still one page doing four jobs.** Food safety,
   supplier certificates, cleaning records, operational evidence. Only the nav
   label changed in V11.3; the structural split is V11.3b.
3. **Owner-only enforcement** for `/admin/releases` and `/admin/audit` is checked
   at the middleware layer first (`isOwnerOnlyPath`) — verified by
   `route-protection.spec.ts` ("managers cannot reach owner-only release/audit").
