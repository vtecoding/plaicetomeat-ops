# 01 — Route Inventory

Every route in the app at commit `ac1603e`, with access level, what it reads, what
it can write, and (for V11) redirect/retirement behaviour. 40 route entries in the
production build; 40 `page.tsx` files.

Access levels: **PUBLIC** (no auth), **STAFF** (counter staff + above),
**MANAGER** (manager + owner), **OWNER** (owner only). Enforcement layers in
[05-permissions-and-roles-map.md](05-permissions-and-roles-map.md).

## Public routes

| Route | Access | Reads | Writes (via) | Notes |
|---|---|---|---|---|
| `/` | PUBLIC | `getPublicBranch`, `getPublicProducts` | — | Home/storefront; real catalog data with safe empty-state fallback |
| `/shop` | PUBLIC | catalog | — | Product listing |
| `/product/[slug]` | PUBLIC | catalog | — | Product detail; "Add" to basket (client) |
| `/basket` | PUBLIC | client state | — | Basket (localStorage) |
| `/checkout` | PUBLIC | catalog, pickup windows | `create_checkout_order` → grants signed order-access session | **Fails closed** if `ORDER_ACCESS_SECRET` unset in prod (see README note 4) |
| `/our-halal-promise` | PUBLIC | static + supplier-safe data | — | No supplier contact disclosure (e2e-verified) |
| `/privacy` | PUBLIC | static | — | |
| `/login` | PUBLIC | — | `loginAction` (auth) | Non-enumerating error; login-attempt throttling |
| `/auth/update-password` | PUBLIC (token) | — | Supabase auth | Password reset landing |
| `/order/lookup` | PUBLIC | — | `establish_public_order_access` (server, rate-limited) | Identity check: order ref + phone → grants session → redirects to status |
| `/order/status/[publicAccessId]` | PUBLIC (handle) | `get_public_order_status` (anon RPC, safe DTO) | — | Read keyed by **unguessable** id; not the reference |
| `/order/status/[publicAccessId]/cancel` | PUBLIC (handle + session) | status | `cancel_public_order` (server, service-role, version-bound) | **Requires established signed session** to cancel |
| `/order/[orderRef]` | PUBLIC → **REDIRECT** | — | — | **V11.1:** redirects to `/order/lookup?ref=…`; reads/renders no order data |
| `/order/[orderRef]/cancel` | PUBLIC → **REDIRECT** | — | — | **V11.1:** redirects to `/order/lookup`; reference-only cancel removed |

## Staff routes (middleware: `/counter/:path*`)

| Route | Access | Reads | Writes (via) | Notes |
|---|---|---|---|---|
| `/counter` | STAFF | orders (RLS) | `transition_order_status`, notes | Live service board; realtime + polling fallback |
| `/counter/orders/[id]` | STAFF | order detail | `transition_order_status`, `add_order_note` | Single-order operate view |
| `/counter/compliance` | STAFF | compliance logs/readings | `compliance-inventory` action | Nav-relabelled "Food safety" (V11.3); structural 4-domain split **deferred to V11.3b** |

## Manager routes (middleware: `/admin/:path*`)

| Route | Access | Purpose | Writes (via) |
|---|---|---|---|
| `/admin` | MANAGER | **Business Insights** — analysis only (V11.3) | — (read-only analysis) |
| `/admin/today` | MANAGER | **TODAY** — the single operational home (Owner Brain) | navigates to decision cards |
| `/admin/today/[id]` | MANAGER | Decision card (standardised) | varies by action |
| `/admin/today/walk` | MANAGER | Optional guided walk through the day (V10) | — |
| `/admin/briefing` | MANAGER → **REDIRECT** | **V11.3:** retired; `redirect("/admin/today")` (9-line stub) | — |
| `/admin/open` | MANAGER | Opening ritual checklist | `ops_start_or_resume_session`, `ops_record_step`, `ops_complete_session` |
| `/admin/close` | MANAGER | Closing ritual checklist | ops_* RPCs |
| `/admin/stock-count` | MANAGER | **Single stock-correction door** (V11.3) | `ops_record_stock_count_line`, `ops_apply_stock_count_line` |
| `/admin/orders` | MANAGER | Order history / search / exceptions (reframed V11.3) | `transition_order_status` |
| `/admin/products` | MANAGER | Product catalog management | `admin_create_product`, `admin_update_product`, price/availability RPCs |
| `/admin/inventory` | MANAGER | Inventory batches; per-batch "Correct stock" now **owner-only** (V11.3) | `admin_create_inventory_batch`, `admin_adjust_inventory_remaining`, `admin_record_inventory_waste` |
| `/admin/purchasing` | MANAGER | Purchasing decision support | — |
| `/admin/cutting-guide` | MANAGER | Cutting & pricing guide (yields) | `admin_set_product_cost`, `admin_commit_product_price_cost` |
| `/admin/compliance` | MANAGER | Compliance dashboard + supplier certificates | `admin_upsert_supplier_cert` |
| `/admin/pickup-windows` | MANAGER | Pickup window admin | `admin_create/update/set_active_pickup_window` |
| `/admin/shop-closures` | MANAGER | Shop closure admin | `admin_create/remove_shop_closure` |
| `/admin/settings` | MANAGER | Branch settings | `admin_update_branch_settings` |
| `/admin/setup` | MANAGER | Guided setup checklist (launch readiness home) | setup RPCs |
| `/admin/guide` | MANAGER | Owner guide / runbook | — |
| `/admin/playbooks` | MANAGER | Operational playbooks index | — |
| `/admin/playbooks/[slug]` | MANAGER | Playbook detail | — |

## Owner-only routes (`isOwnerOnlyPath`)

| Route | Access | Purpose | Writes (via) |
|---|---|---|---|
| `/admin/releases` | OWNER | Release governance / deployment certification | `create_release_deployment`, `certify_release`, verification RPCs |
| `/admin/audit` | OWNER | Audit-log investigation (append-only evidence) | — (read-only) |

## Retirement / redirect behaviour summary (V11)

| Old surface | Now | Mechanism |
|---|---|---|
| `/order/<ref>` (order data by reference) | redirect to `/order/lookup` | `redirect()`; **no order read** |
| `/order/<ref>/cancel` (cancel by reference) | redirect to `/order/lookup` | reference-only cancel **dropped** in SQL too |
| `/admin/briefing` (daily briefing dashboard) | redirect to `/admin/today` | 9-line stub; analysis moved to `/admin` |
| `/admin?mode=counter` (duplicate counter view) | falls through to Business Insights | `mode=counter` branch removed; 0 refs in `src/` |

## Notes & findings

- **`/compliance/:path*` is still in the middleware matcher** (`src/middleware.ts:93`)
  but **no top-level `/compliance` route exists** — the compliance page is
  `/counter/compliance`. The matcher entry is harmless (defensive/legacy) but is
  dead config worth pruning. Flagged LOW in [11](11-risk-and-duplication-map.md).
- **`force-dynamic`** is set on the public order routes so the redirect/handle
  logic always runs server-side per request.
- The build marks all non-static routes `ƒ (Dynamic)`; the storefront product
  pages are SSG with `generateStaticParams`.
