# 12 — Launch Readiness Map

Strict statuses: **READY** · **NEEDS ATTENTION** · **BLOCKER** · **UNKNOWN**.
A category is **READY** only with evidence at the relevant level. Production claims
require production evidence — which this pack does not have.

## Category scorecard

| Category | Status | Basis |
|---|---|---|
| **Local code readiness** | **READY** | typecheck PASS, 288/288 unit, 99/99 e2e (with secret), build clean, `audit:bundle` CLEAN |
| **PR stack readiness** | **NEEDS ATTENTION** | 3 open stacked PRs (#12←#13←#14); merge-order-sensitive; `main` has none of V11 |
| **Production readiness** | **BLOCKER** | 3 V11 migrations not on remote (drift FAIL); deployed commit UNKNOWN; no hosted smoke |
| **Security readiness (repo)** | **READY** | 24/24 public-access + design proven ([14](14-security-boundary-map.md)) |
| **Security readiness (prod)** | **BLOCKER** | not deployed; `ORDER_ACCESS_SECRET` prod status UNKNOWN |
| **Audit authenticity (repo)** | **READY** | 41/41 adversarial + self-enforcing migration ([15](15-audit-authenticity-map.md)) |
| **Audit authenticity (prod)** | **BLOCKER** | migration not applied to remote |
| **Owner usability** | **READY** | consolidation done; Owner-Brain language firewall; e2e `owner-brain` |
| **Staff usability** | **READY** | counter usability/persistence/realtime/degraded all green |
| **Inventory truth** | **NEEDS ATTENTION** | no auto-depletion; manual stock-count only (V11.5 not started) |
| **Pricing truth** | **NEEDS ATTENTION** | yields unverified by a butcher (V11.8 not started) |
| **Compliance readiness** | **NEEDS ATTENTION** | works, but 4-domain split + temperature single-source deferred (V11.3b) |
| **Deployment/recovery readiness** | **NEEDS ATTENTION** | manual single-person deploy; rollback documented not tested; no CI |
| **Observability** | **NEEDS ATTENTION** | no error-tracking/alerting/synthetic monitor evident |
| **Test coverage** | **READY (with gaps)** | strong unit+e2e+adversarial; named gaps in [17](17-playwright-coverage-map.md) (owner-only content, UI non-enumeration) |

## The honest one-paragraph verdict

The **code** is in good shape and the V11 security work is real and verified at the
repository level. The system is **not launch-ready**, and the reasons are not about
code quality — they are: (1) **production is not sealed** (migrations not deployed,
secret unverified, no hosted smoke); (2) **two business-truth questions remain
open** (yield/pricing sign-off, inventory reconciliation); and (3) **operational
maturity gaps** (no CI, manual single-person release, untested rollback, no
production observability). Do **not** call this launch-ready until production,
security, recovery and operational workflows are proven **in production**.

## Top-10 to reach launch (ordered)

1. Set `ORDER_ACCESS_SECRET` (≥32 bytes) in production. **[BLOCKER B2]**
2. Merge #12; apply V11.1 migrations to prod; execute Production Gate A. **[B1]**
3. Verify the public-order boundary against the deployed prod (hosted smoke). **[B1]**
4. Merge #13; apply V11.2 audit migration; verify audit authenticity in prod. **[B1]**
5. Merge #14; deploy consolidation; confirm Today/Business-Insights live. **[H3]**
6. Make the demo-data fallback loud in production (or dev-only). **[H1]**
7. Add CI: typecheck + vitest + adversarial scripts + `audit:bundle` on every PR. **[H4]**
8. Butcher sign-off on yields before any real pricing is published. **[H2]**
9. Add basic production observability (error tracking + checkout synthetic monitor). **[M5]**
10. Test a real migration rollback in a staging Supabase project. **[M4]**

## Do-not-launch checklist (any TRUE blocks launch)
- [ ] V11 migrations not applied to production → **currently TRUE**
- [ ] `ORDER_ACCESS_SECRET` not confirmed set in production → **currently TRUE/UNKNOWN**
- [ ] No production smoke run of the secure order flow → **currently TRUE**
- [ ] Yields/prices not signed off → **currently TRUE**
- [ ] No way to detect a production failure → **currently TRUE**

All five are currently TRUE. **Launch is blocked.**
