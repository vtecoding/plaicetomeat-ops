# 09 — Page Screenshot Index

Fresh screenshots captured against a **production build** (`next start -p 3100`,
`ORDER_ACCESS_SECRET` set), seeded local Supabase data, commit `ac1603e`,
2026-06-06. **45/45 captured**, all HTTP 200.

- Images: [`../../screenshots-v11/`](../../screenshots-v11/)
- Manifest: [`../../screenshots-v11/_manifest.json`](../../screenshots-v11/_manifest.json)
  (route, screenshot, http, loginState, role, redirectTarget, timestamp, viewport, note)
- Contact sheets (HTML, openable): [`../../screenshots-v11/contact-sheets/`](../../screenshots-v11/contact-sheets/)
  — `index.html` (all) plus one per group: `public`, `order`, `staff`, `admin`,
  `owner-only`, `mobile`, `roles`.

Capture method: Playwright Chromium, full-page, 1366×900 (390×844 for mobile), via
`scripts/audit-screenshots-v11.mjs` (committed). The screenshot tool is **not** a
correctness proof — it shows what renders, not that the numbers are right.

## Public (anon) — `public`
| # | File | Route | Notes |
|---|---|---|---|
| 1 | `public-01-home.png` | `/` | storefront, real catalog |
| 2 | `public-02-shop.png` | `/shop` | listing |
| 3 | `public-03-product.png` | `/product/[slug]` | detail |
| 4 | `public-04-basket.png` | `/basket` | basket |
| 5 | `public-05-checkout.png` | `/checkout` | checkout form |
| 6 | `public-06-halal-promise.png` | `/our-halal-promise` | no supplier contact leak |
| 7 | `public-07-privacy.png` | `/privacy` | |
| 8 | `public-08-login.png` | `/login` | staff login |

## Secure order flow (V11.1) — `order`
| # | File | Route | Notes |
|---|---|---|---|
| 9 | `order-01-legacy-ref-redirect.png` | `/order/PTM-2026-90001` | **redirects → `/order/lookup?ref=…`** (no data read) |
| 10 | `order-02-legacy-cancel-redirect.png` | `/order/PTM-2026-90001/cancel` | **redirects → `/order/lookup`** |
| 11 | `order-03-lookup.png` | `/order/lookup` | identity check (ref + phone) |
| 12 | `order-04-status-by-accessid.png` | `/order/status/<uuid>` | **secure status by unguessable handle**; first-name-only safe DTO ("Order for Aisha") |
| 13 | `order-05-cancel-with-session.png` | `/order/status/<uuid>/cancel` | cancel reachable **with** established session |
| 14 | `order-06-cancel-no-session-blocked.png` | same URL, fresh browser | **no session → asked to confirm identity, no cancel button** |

> The access id used was established live via the lookup form (`PTM-2026-90001` +
> `07700900111`), so these are real secure-flow renders, not mocks.

## Staff surfaces (as owner) — `staff`
| # | File | Route | Notes |
|---|---|---|---|
| 15 | `staff-01-counter.png` | `/counter` | live service board |
| 16 | `staff-03-food-safety.png` | `/counter/compliance` | nav "Food safety"; split deferred |

_(`staff-02-counter-order` was not captured — the counter board did not expose an
`a[href^="/counter/orders/"]` link in the seeded state; the route itself is in
[01](01-route-inventory.md).)_

## Admin / owner — `admin`
| # | File | Route | Notes |
|---|---|---|---|
| 17 | `admin-01-today.png` | `/admin/today` | **TODAY — sole operational home** |
| 18 | `admin-03-today-walk.png` | `/admin/today/walk` | guided walk |
| 19 | `admin-04-business-insights.png` | `/admin` | **Business Insights — analysis only** |
| 20 | `admin-05-mode-counter-removed.png` | `/admin?mode=counter` | **counter-mode removed** → Business Insights |
| 21 | `admin-06-briefing-redirect.png` | `/admin/briefing` | **RETIRED → redirects to `/admin/today`** |
| 22 | `admin-07-open.png` | `/admin/open` | opening ritual |
| 23 | `admin-08-close.png` | `/admin/close` | closing ritual |
| 24 | `admin-09-stock-count.png` | `/admin/stock-count` | **single stock-correction door** |
| 25 | `admin-10-orders.png` | `/admin/orders` | order history / exceptions |
| 26 | `admin-11-products.png` | `/admin/products` | catalog |
| 27 | `admin-12-inventory.png` | `/admin/inventory` | per-batch correction owner-only |
| 28 | `admin-13-purchasing.png` | `/admin/purchasing` | decision support |
| 29 | `admin-14-cutting-guide.png` | `/admin/cutting-guide` | yields (unverified) |
| 30 | `admin-15-compliance.png` | `/admin/compliance` | compliance dashboard |
| 31 | `admin-16-pickup-windows.png` | `/admin/pickup-windows` | |
| 32 | `admin-17-shop-closures.png` | `/admin/shop-closures` | |
| 33 | `admin-18-settings.png` | `/admin/settings` | branch settings |
| 34 | `admin-21-setup.png` | `/admin/setup` | setup checklist |
| 35 | `admin-22-guide.png` | `/admin/guide` | runbook |
| 36 | `admin-23-playbooks.png` | `/admin/playbooks` | playbooks index |
| 37 | `admin-24-playbook-detail.png` | `/admin/playbooks/[slug]` | playbook detail |

## Owner-only — `owner-only`
| # | File | Route | Notes |
|---|---|---|---|
| 38 | `admin-19-releases.png` | `/admin/releases` | release governance |
| 39 | `admin-20-audit.png` | `/admin/audit` | append-only audit evidence |

## Mobile (owner, 390×844) — `mobile`
| # | File | Route |
|---|---|---|
| 40 | `mobile-01-today.png` | `/admin/today` |
| 41 | `mobile-02-business-insights.png` | `/admin` |

## Role gating — `roles`
| # | File | Route | Role | Notes |
|---|---|---|---|---|
| 42 | `role-staff-01-counter.png` | `/counter` | staff | staff nav: Counter + Food safety only |
| 43 | `role-staff-02-admin-blocked.png` | `/admin/today` | staff | **blocked → redirect to `/`** |
| 44 | `role-manager-01-today.png` | `/admin/today` | manager | manager nav: Today + Business Insights |
| 45 | `role-manager-02-owneronly-blocked.png` | `/admin/releases` | manager | **blocked → redirect to `/`** |

## What these screenshots evidence
- The **consolidation** is visible: Today vs Business Insights are distinct; briefing
  redirects; `?mode=counter` no longer renders a counter.
- The **security boundary** is visible: legacy reference routes redirect with no
  data; secure status shows only a first name; cancellation needs a session.
- **Role gating** is visible: staff and manager are redirected away from
  routes above their level.
