# 15 — Audit Authenticity Map

Scope: the V11.2 audit-authenticity boundary. Goal invariant: **audit evidence is
system-generated and non-forgeable** — no anon/public/staff/manager user may
directly insert, update or delete audit records; writes flow only through trusted
`SECURITY DEFINER` paths.

Evidence: `node scripts/verify-audit-authenticity.mjs` → **41/41 PASS**
([`_validation/verify-audit-authenticity.log`](_validation/verify-audit-authenticity.log)),
the in-migration self-assertion `DO $$ … RAISE EXCEPTION if hole reintroduced`,
and `audit-imports.test.ts`.

## What was wrong before V11.2 (the closed hole)
- `audit_logs` had `"authenticated can create audit logs"` INSERT policy → any
  branch staff could write arbitrary rows (forged event_type/actor/target/metadata,
  or `branch_id = NULL` to bypass the branch check).
- `audit_events` had an even weaker `WITH CHECK auth.uid() IS NOT NULL` → any
  authenticated user could forge `actor_email`, `actor_role='owner'`, ip, ua — and
  `audit_events` is the surface the **admin UI displays**.

## How it is closed (source)
1. **Forgeable policies dropped:** `"authenticated can create audit logs"` and
   `"authenticated can create audit events"` (migration §1).
2. **Direct write grants revoked:** `REVOKE INSERT, UPDATE, DELETE, TRUNCATE …
   FROM anon, authenticated, PUBLIC` on both tables (§2). SELECT retained.
3. **Append-only re-asserted:** `prevent_audit_log_mutation` /
   `prevent_audit_events_mutation` BEFORE UPDATE/DELETE triggers (§3).
4. **Single trusted emitter:** `emit_audit_log` (SD, fail-closed) (§4).
5. **The one INVOKER emitter re-routed:** `transition_order_status` now writes its
   audit row via `emit_audit_log` (its inline insert depended on the dropped
   grant, so it would have failed closed) (§5).
6. **Self-enforcing invariant:** the migration aborts if any residual write grant
   or insert/all policy exists on the audit tables (§6).

## Required claims — proven

| Claim | Mechanism | Adversarial check |
|---|---|---|
| **anon cannot insert audit logs** | grant revoked + no policy | *"anon INSERT audit_logs is DENIED"* ✅ (+ audit_events) |
| **staff cannot forge audit logs** | grant revoked | *"staff direct INSERT audit_logs/events is DENIED"* ✅ |
| **manager cannot forge owner/system audit logs** | `emit_audit_log` forbids non-system caller setting `system_reason`; actor=auth.uid() | *"manager emit with system_reason is DENIED"*, *"manager direct INSERT with forged owner actor is DENIED"* ✅ |
| **audit logs are append-only** | triggers | *"service UPDATE/DELETE audit_logs is DENIED (append-only)"* ✅ (+ events) |
| **audit events cannot be forged** | policy dropped + grant revoked + mirror trigger is the only writer | *"staff/manager direct INSERT audit_events DENIED"* ✅ |
| **trusted emitter is the only valid write path** | SD functions in owner context; `emit_audit_log` for ad-hoc | legitimate flows still emit (below) ✅ |
| **metadata is capped/redacted** | ≤8192 bytes; secret-key strip; `_redacted_keys` recorded | *"secret-like keys are stripped"*, *"non-secret keys retained"*, *"redaction recorded"* ✅ |
| **actor/source/branch cannot be caller-forged** | actor=auth.uid() (no param); branch validated via `is_branch_staff`; created_at server-side | *"emitted actor_id is the staff/manager uid (not forgeable)"*, *"branch_id is the validated branch"*, *"created_at set server-side"*, *"forged created_at DENIED"*, *"manager emit for branch B DENIED"* ✅ |
| **legitimate business flows still emit evidence** | inline SD inserts + re-routed transition | flow checks below ✅ |

## Legitimate flows still produce audit evidence (regression)
All PASS in the adversarial run:
- status transition → `order_status_changed` row
- cancellation → cancellation audit row
- inventory adjustment → `stock_corrected` row
- waste logging → `waste_recorded` row
- product price/cost commit → `pricing_committed` row
- supplier certificate upsert → certificate audit row

## Hardening details
- **`search_path` pinned** on all public SECURITY DEFINER functions — adversarial
  *"all public SECURITY DEFINER functions pin search_path"* ✅ (prevents
  search-path hijack of an SD function).
- **No residual grants/policies** — adversarial *"no INSERT/UPDATE/DELETE grant on
  audit tables for anon/authenticated"*, *"no INSERT/ALL RLS policy remains"* ✅,
  and the migration's own `DO $$` assertion.
- **System emission requires a reason** and records `actor_id = NULL` — service
  emits via `emitSecurityEvent`/`emitAuditLog(systemReason)`; a non-system caller
  passing a system reason is rejected (`42501`).

## Import-graph guardrail (`audit-imports.test.ts`)
- audit modules declare `import "server-only"`;
- **no client component** imports an audit helper;
- `emit_audit_log` is referenced **only** in `src/lib/server/audit.ts`;
- the read module (`audit-events.ts`) performs **no** writes;
- the audit module forces a server-derived actor (no `p_actor`/`p_created_at`/
  `actorId:` surfaced to callers).

## Honest caveats
- **Local proof only.** `202606051400_v11_2_audit_authenticity.sql` is **not** on
  the production DB (drift FAIL). Until applied, production audit tables may still
  carry the forgeable insert policy. See [18](18-production-seal-status.md).
- The boundary trusts that **every** business SD function validates its actor
  before its inline insert. That is true today; a future RPC author could
  re-introduce a weak inline insert. The `emit_audit_log` path is the safer
  default and should be preferred for new code (it is fail-closed by construction).
